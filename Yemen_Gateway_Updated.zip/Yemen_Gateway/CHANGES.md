# سجل التعديلات - Yemen Gateway

## التعديلات المنفّذة

### 1. توحيد نظام التوكن (`yg_token`)
- **جديد:** `app/src/lib/api.ts` — helper مركزي لكل API calls
- تعديل: `Developers.tsx`, `APILogs.tsx`, `AdminPayments.tsx` — `auth_token` → `yg_token`
- تعديل: `Invoices.tsx` — إزالة `auth_token` المتبقية

### 2. نظام الدفع اليدوي
- **جديد:** `app/src/pages/PublicPay.tsx` — صفحة دفع عامة `/pay/:invoiceId`
  - عرض تفاصيل الفاتورة بالكامل
  - دعم: كريمي، جوالي، ون كاش، تحويل بنكي، نقداً
  - فورم إثبات الدفع (اسم، هاتف، طريقة، رقم العملية، ملاحظة)
- **جديد:** `backend/internal/handlers/public.go`
  - `GET /api/v1/public/invoices/:id` — عرض الفاتورة بدون auth
  - `POST /api/v1/public/invoices/:id/pay` — إرسال إثبات دفع
- تعديل: `AdminPayments.tsx` — واجهة مراجعة كاملة (قبول/رفض + ملاحظة)

### 3. نظام الفواتير المكتمل
- **جديد في handler:** `UpdateInvoice`, `DeleteInvoice`, `GetInvoicePDF`, `GetInvoicePayLink`
- **جديد في repo:** `UpdateInvoice`, `GetInvoiceByIDStr`, `UpdateInvoiceStatusByID`
- تعديل `Invoices.tsx`: أزرار رابط الدفع، معاينة، إلغاء
- Routes جديدة:
  - `PUT /api/v1/invoices/:id`
  - `DELETE /api/v1/invoices/:id`
  - `GET /api/v1/invoices/:id/pdf`
  - `GET /api/v1/invoices/:id/pay-link`

### 4. نظام السندات (Vouchers)
- **جديد في handler:** `GetVoucher`, `UpdateVoucher`, `DeleteVoucher`
- **جديد في repo:** `GetVoucher`, `UpdateVoucher`, `CancelVoucher`
- Routes:
  - `GET /api/v1/vouchers/:id`
  - `PUT /api/v1/vouchers/:id`
  - `DELETE /api/v1/vouchers/:id`

### 5. SMS Provider Interface
- **جديد:** `backend/internal/sms/provider.go`
  - Interface `Provider` قابل للتوسعة
  - `MockProvider` — افتراضي، لا يكسر أي شيء
  - `YemenMobileProvider` — stub جاهز للربط
  - Factory `NewProvider()` يقرأ `SMS_PROVIDER` env
- تعديل: `handlers/sms.go` — يستخدم Provider interface + يسجل في DB

### 6. أسعار الصرف
- **جديد في handler:** `AdminUpdateRate` — تعديل يدوي للأسعار
- Route: `PUT /api/v1/admin/currency/rates`
- تعديل: `ExchangeRates.tsx` — لوحة تعديل للأدمن مع أزرار Edit/Save

### 7. الأمان
- **CORS:** يقرأ `ALLOWED_ORIGINS` من env بدل `*` ثابتة
- **API Keys Hashing:** SHA-256 hash عند الحفظ، مقارنة بالـ hash عند التحقق
- **Show Once:** المفتاح يُعرض مرة واحدة فقط عند الإنشاء
- **Ownership checks:** حذف API Key يتحقق من الملكية

### 8. Audit Logs
- **جديد:** `backend/internal/repository/auditlog.go`
- **جديد:** `backend/internal/handlers/auditlog.go`
- **جديد:** `domain.AuditLogEntry` struct
- Routes:
  - `GET /api/v1/audit-logs` (مستخدم)
  - `GET /api/v1/admin/audit-logs` (أدمن)

### 9. صفحة الخطة الحالية
- **جديد:** `app/src/pages/PlanStatus.tsx`
  - عرض الخطة + حالة الاشتراك
  - أشرطة تقدم للاستخدام (فواتير، عملاء، API، webhooks)
- Route: `/plan`
- **جديد في repo:** `GetUserPlan`
- Route backend: `GET /api/v1/subscription/status`

### 10. Webhooks
- **جديد في repo:** `FindByUser`, `CreateDelivery`
- **جديد في handler:** `sendWebhook` helper مع HMAC توقيع
- Webhook يُطلق عند: `payment.pending_review`

---

## الملفات المضافة
```
app/src/lib/api.ts
app/src/pages/PublicPay.tsx
app/src/pages/PlanStatus.tsx
backend/internal/handlers/public.go
backend/internal/handlers/auditlog.go
backend/internal/repository/auditlog.go
backend/internal/sms/provider.go
backend/migrations/001_audit_log_entries.sql
backend/migrations/002_sms_provider.sql
backend/migrations/003_currency_defaults.sql
```

## الملفات المعدّلة
```
app/src/App.tsx
app/src/components/Sidebar.tsx
app/src/pages/AdminPayments.tsx
app/src/pages/Invoices.tsx
app/src/pages/ExchangeRates.tsx
backend/cmd/api/main.go
backend/internal/config/config.go
backend/internal/database/database.go
backend/internal/domain/invoicing_extended.go
backend/internal/handlers/apikey.go
backend/internal/handlers/billing.go
backend/internal/handlers/currency.go
backend/internal/handlers/invoicing.go
backend/internal/handlers/sms.go
backend/internal/handlers/webhook.go
backend/internal/repository/apikey.go
backend/internal/repository/invoicing.go
backend/internal/repository/plan.go
backend/internal/repository/webhook.go
backend/.env.example
app/.env.example
```

---

## متغيرات ENV الجديدة
```env
# CORS - مطلوب في الإنتاج
ALLOWED_ORIGINS=https://yourdomain.com,https://app.yourdomain.com

# SMS Provider
SMS_PROVIDER=mock          # أو: yemen_mobile
SMS_API_KEY=               # لـ yemen_mobile فقط
SMS_SENDER_ID=YemenGW
SMS_BASE_URL=              # رابط API مزود SMS

# البيئة
SERVER_ENV=development     # أو: production
```

---

## أوامر التشغيل
```bash
# Backend
cd backend
cp .env.example .env
# عدّل .env بالقيم الصحيحة
go run ./cmd/api/...

# Frontend
cd app
cp .env.example .env
# عدّل VITE_API_URL
npm install
npm run dev
```

## تطبيق Migrations
```bash
# الـ AutoMigrate يعمل تلقائياً عند تشغيل الـ backend
# للـ migrations اليدوية:
psql $DATABASE_URL -f backend/migrations/001_audit_log_entries.sql
psql $DATABASE_URL -f backend/migrations/002_sms_provider.sql
psql $DATABASE_URL -f backend/migrations/003_currency_defaults.sql
```

---

## ملاحظات مهمة قبل النشر

1. **ALLOWED_ORIGINS** — لا تتركها فارغة في الإنتاج
2. **JWT_SECRET** — يجب أن يكون طويلاً وعشوائياً (32+ حرف)
3. **API Keys** — مُشفّرة الآن بـ SHA-256، المفاتيح القديمة قبل التحديث لن تعمل — يجب إعادة إنشائها
4. **SMS_PROVIDER=mock** — افتراضي ولن يرسل رسائل حقيقية، آمن للاختبار
5. **صفحة `/pay/:id`** — عامة بدون مصادقة، تأكد من صحة بيانات الفواتير المعروضة
6. **PDF** — endpoint موجود لكن يعيد JSON؛ لتوليد PDF فعلي استخدم مكتبة مثل `gotenberg` أو `wkhtmltopdf` لاحقاً

