package repository

import (
	"time"
	"yemenapi/internal/domain"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type AuditLogRepository struct {
	db *gorm.DB
}

func NewAuditLogRepository(db *gorm.DB) *AuditLogRepository {
	return &AuditLogRepository{db: db}
}

func (r *AuditLogRepository) Log(userID uuid.UUID, action, entity, entityID, details, ip string) error {
	entry := &domain.AuditLogEntry{
		ID:        uuid.New(),
		UserID:    userID,
		Action:    action,
		Entity:    entity,
		EntityID:  entityID,
		Details:   details,
		IP:        ip,
		CreatedAt: time.Now(),
	}
	return r.db.Create(entry).Error
}

func (r *AuditLogRepository) ListByUser(userID string, limit int) ([]domain.AuditLogEntry, error) {
	var entries []domain.AuditLogEntry
	err := r.db.Where("user_id = ?", userID).
		Order("created_at DESC").
		Limit(limit).
		Find(&entries).Error
	return entries, err
}

func (r *AuditLogRepository) ListAll(limit int) ([]domain.AuditLogEntry, error) {
	var entries []domain.AuditLogEntry
	err := r.db.Order("created_at DESC").Limit(limit).Find(&entries).Error
	return entries, err
}
