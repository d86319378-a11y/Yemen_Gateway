package repository

import (
	"crypto/sha256"
	"fmt"
	"time"
	"yemenapi/internal/domain"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type APIKeyRepository struct {
	db *gorm.DB
}

func NewAPIKeyRepository(db *gorm.DB) *APIKeyRepository {
	return &APIKeyRepository{db: db}
}

// HashKey returns SHA-256 hash of the key for storage
func HashKey(key string) string {
	h := sha256.Sum256([]byte(key))
	return fmt.Sprintf("%x", h)
}

func (r *APIKeyRepository) Create(key *domain.APIKey) error {
	// Store hash, keep raw Key temporarily for return to user
	key.Key = HashKey(key.Key)
	return r.db.Create(key).Error
}

func (r *APIKeyRepository) FindByID(id string) (*domain.APIKey, error) {
	var key domain.APIKey
	err := r.db.Where("id = ?", id).First(&key).Error
	return &key, err
}

// FindByKey searches by hash of the provided raw key
func (r *APIKeyRepository) FindByKey(rawKey string) (*domain.APIKey, error) {
	var key domain.APIKey
	hashed := HashKey(rawKey)
	err := r.db.Where("key = ?", hashed).First(&key).Error
	return &key, err
}

func (r *APIKeyRepository) FindByUser(userID string) ([]domain.APIKey, error) {
	var keys []domain.APIKey
	err := r.db.Where("user_id = ?", userID).Find(&keys).Error
	return keys, err
}

func (r *APIKeyRepository) Update(key *domain.APIKey) error {
	return r.db.Save(key).Error
}

func (r *APIKeyRepository) UpdateLastUsed(id string) error {
	now := time.Now()
	return r.db.Model(&domain.APIKey{}).Where("id = ?", id).Updates(map[string]interface{}{
		"last_used_at": now,
		"usage_count":  gorm.Expr("usage_count + 1"),
	}).Error
}

func (r *APIKeyRepository) UpdateStatus(id string, status string) error {
	return r.db.Model(&domain.APIKey{}).Where("id = ?", id).Update("status", status).Error
}

func (r *APIKeyRepository) Delete(id string) error {
	return r.db.Delete(&domain.APIKey{}, "id = ?", id).Error
}

func (r *APIKeyRepository) CountByUser(userID uuid.UUID) (int64, error) {
	var count int64
	err := r.db.Model(&domain.APIKey{}).Where("user_id = ?", userID).Count(&count).Error
	return count, err
}
