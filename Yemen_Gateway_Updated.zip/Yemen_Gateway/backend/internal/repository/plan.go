package repository

import (
	"yemenapi/internal/domain"

	"gorm.io/gorm"
)

type PlanRepository struct {
	db *gorm.DB
}

func NewPlanRepository(db *gorm.DB) *PlanRepository {
	return &PlanRepository{db: db}
}

func (r *PlanRepository) FindBySlug(slug string) (*domain.Plan, error) {
	var plan domain.Plan
	err := r.db.Where("slug = ?", slug).First(&plan).Error
	return &plan, err
}

func (r *PlanRepository) List() ([]domain.Plan, error) {
	var plans []domain.Plan
	err := r.db.Find(&plans).Error
	return plans, err
}

func (r *PlanRepository) Create(plan *domain.Plan) error {
	return r.db.Create(plan).Error
}

func (r *PlanRepository) Update(plan *domain.Plan) error {
	return r.db.Save(plan).Error
}

func (r *PlanRepository) Delete(id string) error {
	return r.db.Delete(&domain.Plan{}, "id = ?", id).Error
}

// GetUserPlan returns basic plan info for the given userID
// Returns a map suitable for JSON response
func (r *PlanRepository) GetUserPlan(userID string) (map[string]interface{}, error) {
	type subRow struct {
		PlanSlug  string
		PlanName  string
		Status    string
		ExpiresAt *string
	}

	var row subRow
	err := r.db.Raw(`
		SELECT p.slug as plan_slug, p.name as plan_name, s.status, s.ends_at::text as expires_at
		FROM subscriptions s
		JOIN plans p ON p.id = s.plan_id
		WHERE s.user_id = ? AND s.status = 'active'
		ORDER BY s.created_at DESC
		LIMIT 1
	`, userID).Scan(&row).Error

	if err != nil || row.PlanSlug == "" {
		return nil, err
	}

	plan, err := r.FindBySlug(row.PlanSlug)
	if err != nil {
		return nil, err
	}

	return map[string]interface{}{
		"plan_name":  plan.Name,
		"plan_slug":  plan.Slug,
		"status":     row.Status,
		"expires_at": row.ExpiresAt,
		"limits": map[string]interface{}{
			"invoices_per_month":   plan.Limits.Requests / 10,
			"customers":            plan.Limits.Keys * 50,
			"api_calls_per_month":  plan.Limits.Requests,
			"webhooks":             plan.Limits.Keys,
		},
		"usage": map[string]int{
			"invoices_this_month":  0,
			"customers":            0,
			"api_calls_this_month": 0,
			"webhooks":             0,
		},
	}, nil
}
