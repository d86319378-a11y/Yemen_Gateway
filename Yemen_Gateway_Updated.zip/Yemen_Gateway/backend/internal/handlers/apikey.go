package handlers

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"yemenapi/internal/domain"
	"yemenapi/internal/repository"
)

type APIKeyHandler struct {
	repo *repository.APIKeyRepository
}

func NewAPIKeyHandler(repo *repository.APIKeyRepository) *APIKeyHandler {
	return &APIKeyHandler{repo: repo}
}

type CreateAPIKeyRequest struct {
	Name string `json:"name"`
}

func (h *APIKeyHandler) List(c *gin.Context) {
	userID := c.GetString("user_id")

	keys, err := h.repo.FindByUser(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"success": false, "error": "failed to load keys"})
		return
	}

	// Never return hashed keys — return prefix only
	safe := make([]gin.H, 0, len(keys))
	for _, k := range keys {
		safe = append(safe, gin.H{
			"id":           k.ID,
			"name":         k.Name,
			"prefix":       k.Prefix,
			"status":       k.Status,
			"usage_count":  k.UsageCount,
			"last_used_at": k.LastUsedAt,
			"created_at":   k.CreatedAt,
		})
	}

	c.JSON(http.StatusOK, gin.H{"success": true, "data": safe})
}

func (h *APIKeyHandler) Create(c *gin.Context) {
	userID := c.GetString("user_id")

	var req CreateAPIKeyRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"success": false, "error": err.Error()})
		return
	}

	uid, err := uuid.Parse(userID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"success": false, "error": "invalid user"})
		return
	}

	// Generate raw key — will be shown ONCE then hashed in repo
	rawKey := "yg_" + strings.ReplaceAll(uuid.New().String(), "-", "")

	key := &domain.APIKey{
		UserID: uid,
		Name:   req.Name,
		Key:    rawKey, // repo.Create will hash this
		Prefix: rawKey[:12],
		Status: "active",
	}

	if err := h.repo.Create(key); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"success": false, "error": err.Error()})
		return
	}

	// Return raw key ONCE — after this it's only stored hashed
	c.JSON(http.StatusCreated, gin.H{
		"success": true,
		"data": gin.H{
			"id":     key.ID,
			"name":   key.Name,
			"key":    rawKey, // shown only once
			"prefix": key.Prefix,
			"status": key.Status,
			"note":   "احفظ هذا المفتاح الآن — لن يظهر مجدداً",
		},
	})
}

func (h *APIKeyHandler) Delete(c *gin.Context) {
	id := c.Param("id")
	userID := c.GetString("user_id")

	// Verify ownership before delete
	key, err := h.repo.FindByID(id)
	if err != nil || key.UserID.String() != userID {
		c.JSON(http.StatusForbidden, gin.H{"success": false, "error": "غير مصرح"})
		return
	}

	if err := h.repo.Delete(id); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"success": false, "error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true})
}
