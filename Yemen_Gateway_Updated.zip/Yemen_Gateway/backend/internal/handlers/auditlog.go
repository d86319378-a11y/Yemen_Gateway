package handlers

import (
	"net/http"
	"strconv"
	"yemenapi/internal/domain"
	"yemenapi/internal/repository"

	"github.com/gin-gonic/gin"
)

type AuditLogHandler struct {
	repo *repository.AuditLogRepository
}

func NewAuditLogHandler(repo *repository.AuditLogRepository) *AuditLogHandler {
	return &AuditLogHandler{repo: repo}
}

// MyLogs — عرض سجل عمليات المستخدم الحالي
func (h *AuditLogHandler) MyLogs(c *gin.Context) {
	userID := c.GetString("user_id")
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "50"))
	if limit > 200 {
		limit = 200
	}

	entries, err := h.repo.ListByUser(userID, limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "failed to fetch logs"})
		return
	}

	c.JSON(http.StatusOK, domain.APIResponse{Success: true, Data: entries})
}

// AdminAllLogs — عرض جميع السجلات (أدمن فقط)
func (h *AuditLogHandler) AdminAllLogs(c *gin.Context) {
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "100"))
	if limit > 500 {
		limit = 500
	}

	entries, err := h.repo.ListAll(limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "failed to fetch logs"})
		return
	}

	c.JSON(http.StatusOK, domain.APIResponse{Success: true, Data: entries})
}
