package handlers

import (
	"net/http"
	"time"

	"yemenapi/internal/domain"
	"yemenapi/internal/repository"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type PublicHandler struct {
	invoicingRepo *repository.InvoicingRepository
	webhookRepo   *repository.WebhookRepository
}

func NewPublicHandler(invoicingRepo *repository.InvoicingRepository, webhookRepo *repository.WebhookRepository) *PublicHandler {
	return &PublicHandler{invoicingRepo: invoicingRepo, webhookRepo: webhookRepo}
}

// GetPublicInvoice - عرض الفاتورة للعموم بدون مصادقة
func (h *PublicHandler) GetPublicInvoice(c *gin.Context) {
	id := c.Param("id")
	invoice, err := h.invoicingRepo.GetInvoiceByIDStr(id)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "الفاتورة غير موجودة"})
		return
	}

	c.JSON(http.StatusOK, domain.APIResponse{
		Success: true,
		Data: gin.H{
			"id":             invoice.ID,
			"number":         invoice.Number,
			"customer_name":  invoice.CustomerName,
			"customer_phone": invoice.CustomerPhone,
			"customer_email": invoice.CustomerEmail,
			"currency":       invoice.Currency,
			"subtotal":       invoice.Subtotal,
			"tax":            invoice.Tax,
			"discount":       invoice.Discount,
			"total":          invoice.Total,
			"status":         invoice.Status,
			"notes":          invoice.Notes,
			"due_date":       invoice.DueDate,
			"created_at":     invoice.CreatedAt,
			"items":          invoice.Items,
		},
	})
}

// SubmitPublicPayment - إرسال إثبات دفع بدون مصادقة
func (h *PublicHandler) SubmitPublicPayment(c *gin.Context) {
	id := c.Param("id")

	invoice, err := h.invoicingRepo.GetInvoiceByIDStr(id)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "الفاتورة غير موجودة"})
		return
	}

	if invoice.Status == "paid" {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "هذه الفاتورة مدفوعة بالفعل"})
		return
	}
	if invoice.Status == "cancelled" || invoice.Status == "expired" {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "هذه الفاتورة ملغاة أو منتهية الصلاحية"})
		return
	}

	var req struct {
		Provider    string  `json:"provider" binding:"required"`
		SenderName  string  `json:"sender_name"`
		SenderPhone string  `json:"sender_phone"`
		Amount      float64 `json:"amount"`
		Currency    string  `json:"currency"`
		Reference   string  `json:"reference" binding:"required"`
		Notes       string  `json:"notes"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: err.Error()})
		return
	}

	proof := &domain.ManualPaymentProof{
		ID:          uuid.New(),
		UserID:      invoice.UserID,
		InvoiceID:   invoice.ID,
		Provider:    req.Provider,
		SenderName:  req.SenderName,
		SenderPhone: req.SenderPhone,
		Amount:      req.Amount,
		Currency:    req.Currency,
		Reference:   req.Reference,
		Status:      "pending",
	}

	if err := h.invoicingRepo.CreatePaymentProof(proof); err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "فشل حفظ البيانات"})
		return
	}

	// Update invoice to pending_review
	_ = h.invoicingRepo.UpdateInvoiceStatusByID(id, "pending_review", nil)

	// Fire webhook async
	if h.webhookRepo != nil {
		go func() {
			hooks, _ := h.webhookRepo.FindByUser(invoice.UserID.String())
			for _, hook := range hooks {
				if hook.Active {
					now := time.Now()
					attempt := &domain.WebhookDelivery{
						WebhookID: hook.ID,
						Event:       "payment.pending_review",
						AttemptedAt: now,
					}
					_ = h.webhookRepo.CreateDelivery(attempt)
					sendWebhook(hook.URL, hook.Secret, "payment.pending_review", map[string]interface{}{
						"invoice_id":   invoice.ID,
						"proof_id":     proof.ID,
						"amount":       proof.Amount,
						"provider":     proof.Provider,
						"submitted_at": now,
					})
				}
			}
		}()
	}

	c.JSON(http.StatusOK, domain.APIResponse{
		Success: true,
		Data: gin.H{
			"proof_id": proof.ID,
			"status":   "pending_review",
			"message":  "تم استلام إثبات الدفع وسيتم مراجعته قريباً",
		},
	})
}
