package handlers

import (
	"net/http"
	"time"
	"yemenapi/internal/domain"
	"yemenapi/internal/sms"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type SMSHandler struct {
	provider sms.Provider
	db       *gorm.DB
}

func NewSMSHandler() *SMSHandler {
	return &SMSHandler{
		provider: sms.NewProvider(),
	}
}

func NewSMSHandlerWithDB(db *gorm.DB) *SMSHandler {
	return &SMSHandler{
		provider: sms.NewProvider(),
		db:       db,
	}
}

type SendSMSRequest struct {
	To      string `json:"to" binding:"required"`
	Message string `json:"message" binding:"required,max=160"`
	Type    string `json:"type" binding:"omitempty,oneof=otp notification marketing"`
}

type BulkSMSRequest struct {
	Recipients []string `json:"recipients" binding:"required,min=1,max=1000"`
	Message    string   `json:"message" binding:"required,max=160"`
}

type SMSStatusRequest struct {
	MessageID string `json:"message_id" binding:"required"`
}

func (h *SMSHandler) Send(c *gin.Context) {
	var req SendSMSRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: err.Error()})
		return
	}

	msgType := req.Type
	if msgType == "" {
		msgType = "notification"
	}

	result, err := h.provider.Send(req.To, req.Message, msgType)
	if err != nil {
		c.JSON(http.StatusServiceUnavailable, domain.APIResponse{Success: false, Error: "SMS provider error: " + err.Error()})
		return
	}

	// Persist log to DB if available
	if h.db != nil {
		log := &domain.SMSLog{
			ID:       uuid.New(),
			To:       req.To,
			Message:  req.Message,
			Type:     msgType,
			Status:   result.Status,
			Provider: result.Provider,
			Cost:     result.Cost,
		}
		h.db.Create(log)
	}

	c.JSON(http.StatusOK, domain.APIResponse{
		Success: true,
		Data: map[string]interface{}{
			"message_id": result.MessageID,
			"status":     result.Status,
			"to":         req.To,
			"type":       msgType,
			"provider":   result.Provider,
			"cost":       result.Cost,
			"characters": len(req.Message),
			"segments":   (len(req.Message) / 160) + 1,
		},
	})
}

func (h *SMSHandler) Bulk(c *gin.Context) {
	var req BulkSMSRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: err.Error()})
		return
	}

	batchID := uuid.New()
	total := len(req.Recipients)
	accepted := 0
	rejected := 0
	var totalCost float64

	for _, to := range req.Recipients {
		result, err := h.provider.Send(to, req.Message, "notification")
		if err != nil {
			rejected++
			continue
		}
		accepted++
		totalCost += result.Cost

		if h.db != nil {
			log := &domain.SMSLog{
				ID:       uuid.New(),
				To:       to,
				Message:  req.Message,
				Type:     "notification",
				Status:   result.Status,
				Provider: result.Provider,
				Cost:     result.Cost,
			}
			h.db.Create(log)
		}
	}

	c.JSON(http.StatusOK, domain.APIResponse{
		Success: true,
		Data: map[string]interface{}{
			"batch_id": batchID,
			"total":    total,
			"accepted": accepted,
			"rejected": rejected,
			"cost":     totalCost,
			"status":   "queued",
			"provider": h.provider.Name(),
		},
	})
}

func (h *SMSHandler) Status(c *gin.Context) {
	var req SMSStatusRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "message_id is required"})
		return
	}

	// Check DB if available
	if h.db != nil {
		var log domain.SMSLog
		if err := h.db.Where("id = ?", req.MessageID).First(&log).Error; err == nil {
			c.JSON(http.StatusOK, domain.APIResponse{
				Success: true,
				Data: map[string]interface{}{
					"message_id": log.ID,
					"status":     log.Status,
					"to":         log.To,
					"provider":   log.Provider,
					"sent_at":    log.CreatedAt,
				},
			})
			return
		}
	}

	c.JSON(http.StatusOK, domain.APIResponse{
		Success: true,
		Data: map[string]interface{}{
			"message_id":   req.MessageID,
			"status":       "unknown",
			"checked_at":   time.Now(),
			"provider":     h.provider.Name(),
		},
	})
}
