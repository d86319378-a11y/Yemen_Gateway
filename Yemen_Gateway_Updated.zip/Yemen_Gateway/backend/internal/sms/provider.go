package sms

import (
	"fmt"
	"log"
	"os"
	"time"
)

// SendResult is returned from any provider
type SendResult struct {
	MessageID string
	Status    string
	Cost      float64
	Provider  string
	SentAt    time.Time
}

// Provider interface — implement this for any real SMS gateway
type Provider interface {
	Send(to, message, msgType string) (*SendResult, error)
	Name() string
}

// ======= Mock Provider (default — for dev/testing) =======

type MockProvider struct{}

func (m *MockProvider) Name() string { return "mock" }

func (m *MockProvider) Send(to, message, msgType string) (*SendResult, error) {
	id := fmt.Sprintf("mock_%d", time.Now().UnixNano())
	log.Printf("[SMS-MOCK] to=%s type=%s msg=%s id=%s", to, msgType, message, id)
	return &SendResult{
		MessageID: id,
		Status:    "queued",
		Cost:      0,
		Provider:  "mock",
		SentAt:    time.Now(),
	}, nil
}

// ======= Yemen Mobile SMS (stub — fill in with real API later) =======

type YemenMobileProvider struct {
	APIKey    string
	SenderID  string
	BaseURL   string
}

func (y *YemenMobileProvider) Name() string { return "yemen_mobile" }

func (y *YemenMobileProvider) Send(to, message, msgType string) (*SendResult, error) {
	// TODO: implement real HTTP call to Yemen Mobile SMS API
	// POST y.BaseURL/send with auth header y.APIKey
	return nil, fmt.Errorf("Yemen Mobile SMS provider not yet implemented — set SMS_PROVIDER=mock")
}

// ======= Factory: pick provider from env =======

func NewProvider() Provider {
	providerName := os.Getenv("SMS_PROVIDER")
	switch providerName {
	case "yemen_mobile":
		return &YemenMobileProvider{
			APIKey:   os.Getenv("SMS_API_KEY"),
			SenderID: os.Getenv("SMS_SENDER_ID"),
			BaseURL:  os.Getenv("SMS_BASE_URL"),
		}
	default:
		// Safe default: mock — never crashes if no env is set
		return &MockProvider{}
	}
}
