-- Migration 003: Add source/date to currency_rates + seed defaults
ALTER TABLE currency_rates ADD COLUMN IF NOT EXISTS source VARCHAR(50) DEFAULT 'manual_admin';
ALTER TABLE currency_rates ADD COLUMN IF NOT EXISTS date TIMESTAMP WITH TIME ZONE DEFAULT NOW();

INSERT INTO currency_rates (id, from_code, to_code, rate, source, date)
SELECT gen_random_uuid(), 'USD', 'YER', 1300.0, 'default', NOW()
WHERE NOT EXISTS (SELECT 1 FROM currency_rates WHERE from_code='USD' AND to_code='YER');

INSERT INTO currency_rates (id, from_code, to_code, rate, source, date)
SELECT gen_random_uuid(), 'SAR', 'YER', 346.0, 'default', NOW()
WHERE NOT EXISTS (SELECT 1 FROM currency_rates WHERE from_code='SAR' AND to_code='YER');

INSERT INTO currency_rates (id, from_code, to_code, rate, source, date)
SELECT gen_random_uuid(), 'EUR', 'YER', 1408.0, 'default', NOW()
WHERE NOT EXISTS (SELECT 1 FROM currency_rates WHERE from_code='EUR' AND to_code='YER');

INSERT INTO currency_rates (id, from_code, to_code, rate, source, date)
SELECT gen_random_uuid(), 'AED', 'YER', 354.0, 'default', NOW()
WHERE NOT EXISTS (SELECT 1 FROM currency_rates WHERE from_code='AED' AND to_code='YER');
