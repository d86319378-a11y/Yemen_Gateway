-- Migration 002: Add provider field to sms_logs
ALTER TABLE sms_logs ADD COLUMN IF NOT EXISTS provider VARCHAR(50) DEFAULT 'mock';
