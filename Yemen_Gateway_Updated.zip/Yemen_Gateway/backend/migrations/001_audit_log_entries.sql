-- Migration 001: Audit Log Entries table
CREATE TABLE IF NOT EXISTS audit_log_entries (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    action      VARCHAR(100) NOT NULL,
    entity      VARCHAR(100),
    entity_id   VARCHAR(255),
    details     TEXT,
    ip          VARCHAR(50),
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log_entries(created_at DESC);
