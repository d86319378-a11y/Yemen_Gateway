import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Edit2, Save, X } from 'lucide-react';
import { API_BASE_URL } from '@/lib/constants';
import { useAuth } from '@/hooks/useAuth';

type RateItem = {
  rate: number;
  updated_at: string;
};

const CURRENCY_PAIRS = [
  { from: 'USD', to: 'YER', label: 'دولار أمريكي / ريال يمني' },
  { from: 'SAR', to: 'YER', label: 'ريال سعودي / ريال يمني' },
  { from: 'EUR', to: 'YER', label: 'يورو / ريال يمني' },
  { from: 'AED', to: 'YER', label: 'درهم إماراتي / ريال يمني' },
  { from: 'QAR', to: 'YER', label: 'ريال قطري / ريال يمني' },
];

export default function ExchangeRatesPage() {
  const { isAdmin, token } = useAuth();
  const [rates, setRates] = useState<Record<string, RateItem>>({});
  const [loading, setLoading] = useState(true);
  const [editingPair, setEditingPair] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  const fetchRates = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/currency/rates`, {
        headers: { 'X-API-Key': localStorage.getItem('yg_api_key') || '' },
      });
      const data = await res.json();
      if (data.success) setRates(data.data || {});
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchRates(); }, []);

  const startEdit = (pair: string, currentRate: number) => {
    setEditingPair(pair);
    setEditValue(String(currentRate));
    setMessage('');
  };

  const cancelEdit = () => {
    setEditingPair(null);
    setEditValue('');
  };

  const saveRate = async (from: string, to: string) => {
    const rate = parseFloat(editValue);
    if (isNaN(rate) || rate <= 0) {
      setMessage('يرجى إدخال قيمة صحيحة أكبر من صفر');
      return;
    }

    setSaving(true);
    setMessage('');
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/admin/currency/rates`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ from, to, rate }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage('✅ تم تحديث السعر بنجاح');
        setEditingPair(null);
        fetchRates();
      } else {
        setMessage('❌ ' + (data.error || 'فشل التحديث'));
      }
    } catch {
      setMessage('❌ حدث خطأ في الاتصال');
    } finally {
      setSaving(false);
    }
  };

  const getRateForPair = (from: string, to: string): RateItem | null => {
    return rates[`${from}_${to}`] || null;
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">أسعار الصرف</h1>
          <p className="text-sm text-muted-foreground mt-1">
            أسعار العملات مقابل الريال اليمني
            {isAdmin && <Badge variant="outline" className="mr-2">وضع الأدمن — التعديل متاح</Badge>}
          </p>
        </div>
        <Button onClick={fetchRates} variant="outline" className="gap-2">
          <RefreshCw className="h-4 w-4" />
          تحديث
        </Button>
      </div>

      {message && (
        <div className={`p-3 rounded-lg text-sm ${message.startsWith('✅') ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          {message}
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-muted-foreground">جارٍ التحميل...</div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {CURRENCY_PAIRS.map(({ from, to, label }) => {
            const pairKey = `${from}_${to}`;
            const item = getRateForPair(from, to);
            const isEditing = editingPair === pairKey;

            return (
              <Card key={pairKey} className={isEditing ? 'ring-2 ring-blue-400' : ''}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
                    {isAdmin && !isEditing && item && (
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7"
                        onClick={() => startEdit(pairKey, item.rate)}
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {isEditing ? (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <Label className="text-xs">السعر الجديد ({from}/{to})</Label>
                        <Input
                          type="number"
                          value={editValue}
                          onChange={e => setEditValue(e.target.value)}
                          className="text-lg font-bold"
                          autoFocus
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="flex-1 gap-1"
                          onClick={() => saveRate(from, to)}
                          disabled={saving}
                        >
                          <Save className="h-3.5 w-3.5" />
                          {saving ? 'جارٍ الحفظ...' : 'حفظ'}
                        </Button>
                        <Button size="sm" variant="outline" onClick={cancelEdit}>
                          <X className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  ) : item ? (
                    <>
                      <div className="text-3xl font-bold mt-1">
                        {Number(item.rate).toLocaleString('ar-YE')}
                      </div>
                      <div className="text-xs text-muted-foreground mt-2">
                        آخر تحديث: {new Date(item.updated_at).toLocaleString('ar-YE')}
                      </div>
                    </>
                  ) : (
                    <div className="text-sm text-muted-foreground py-2">
                      لم يُضبط بعد
                      {isAdmin && (
                        <Button
                          size="sm"
                          variant="link"
                          className="p-0 mr-2 h-auto text-sm"
                          onClick={() => startEdit(pairKey, 0)}
                        >
                          إضافة
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* All rates raw view */}
      {Object.keys(rates).length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">جميع الأسعار المتاحة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {Object.entries(rates).map(([pair, item]) => (
                <div key={pair} className="flex justify-between items-center p-2 bg-muted/40 rounded text-sm">
                  <span className="font-mono font-medium">{pair}</span>
                  <span>{Number(item.rate).toLocaleString()}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
