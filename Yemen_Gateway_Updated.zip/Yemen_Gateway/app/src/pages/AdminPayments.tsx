import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { API_BASE_URL } from '@/lib/constants';

function getAuthHeaders() {
  return { 'Authorization': `Bearer ${localStorage.getItem('yg_token') || ''}` };
}

type PaymentProof = {
  id: string;
  invoice_id: string;
  provider: string;
  sender_name: string;
  sender_phone: string;
  amount: number;
  currency: string;
  reference: string;
  screenshot_url?: string;
  status: string;
  admin_note?: string;
  created_at: string;
};

const STATUS_MAP: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  pending: { label: 'في الانتظار', variant: 'outline' },
  approved: { label: 'مقبول', variant: 'default' },
  rejected: { label: 'مرفوض', variant: 'destructive' },
};

const PROVIDER_LABELS: Record<string, string> = {
  kuraimi: 'كريمي',
  jawali: 'جوالي',
  onecash: 'ون كاش',
  bank_transfer: 'تحويل بنكي',
  cash: 'نقداً',
};

export default function AdminPaymentsPage() {
  const [payments, setPayments] = useState<PaymentProof[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'pending' | 'all'>('pending');
  const [reviewNote, setReviewNote] = useState<Record<string, string>>({});
  const [processing, setProcessing] = useState<string | null>(null);
  const [message, setMessage] = useState('');

  const fetchPayments = async () => {
    setLoading(true);
    try {
      const url = filter === 'pending'
        ? `${API_BASE_URL}/api/v1/admin/manual-payments?status=pending`
        : `${API_BASE_URL}/api/v1/admin/manual-payments`;
      const res = await fetch(url, { headers: getAuthHeaders() });
      const data = await res.json();
      if (data.success) setPayments(data.data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchPayments(); }, [filter]);

  const review = async (id: string, status: 'approved' | 'rejected') => {
    setProcessing(id);
    setMessage('');
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/admin/manual-payments/${id}/review`, {
        method: 'PUT',
        headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, note: reviewNote[id] || '' }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage(status === 'approved' ? '✅ تم قبول الدفعة' : '❌ تم رفض الدفعة');
        setPayments(prev => prev.map(p => p.id === id ? { ...p, status } : p));
      } else {
        setMessage('خطأ: ' + (data.error || 'فشلت العملية'));
      }
    } finally {
      setProcessing(null);
    }
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">مراجعة المدفوعات</h1>
          <p className="text-sm text-muted-foreground mt-1">
            مراجعة إثباتات الدفع اليدوي من العملاء
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={filter === 'pending' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('pending')}
          >
            المعلّقة فقط
          </Button>
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('all')}
          >
            الكل
          </Button>
          <Button variant="outline" size="sm" onClick={fetchPayments}>تحديث</Button>
        </div>
      </div>

      {message && (
        <div className={`p-3 rounded-lg text-sm border ${message.startsWith('✅') ? 'bg-green-50 text-green-700 border-green-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
          {message}
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-muted-foreground">جارٍ التحميل...</div>
      ) : payments.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            لا توجد مدفوعات {filter === 'pending' ? 'معلّقة' : ''} حالياً
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {payments.map(p => (
            <Card key={p.id} className={p.status === 'pending' ? 'border-orange-200 bg-orange-50/30' : ''}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-base">
                    {PROVIDER_LABELS[p.provider] || p.provider}
                    <span className="text-muted-foreground text-sm font-normal mr-2">
                      — {p.sender_name}
                    </span>
                  </CardTitle>
                  <Badge variant={STATUS_MAP[p.status]?.variant || 'secondary'}>
                    {STATUS_MAP[p.status]?.label || p.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground block">المبلغ</span>
                    <span className="font-bold text-lg">{p.amount.toLocaleString()} {p.currency}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">رقم الهاتف</span>
                    <span>{p.sender_phone || '-'}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">رقم العملية</span>
                    <span className="font-mono">{p.reference}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">رقم الفاتورة</span>
                    <span className="font-mono text-xs">{p.invoice_id.slice(0, 12)}...</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">تاريخ الإرسال</span>
                    <span>{new Date(p.created_at).toLocaleString('ar-YE')}</span>
                  </div>
                </div>

                {p.screenshot_url && (
                  <div>
                    <a
                      href={p.screenshot_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-blue-600 underline"
                    >
                      📎 عرض صورة الإثبات
                    </a>
                  </div>
                )}

                {p.admin_note && (
                  <div className="text-sm bg-gray-100 rounded p-2">
                    ملاحظة: {p.admin_note}
                  </div>
                )}

                {p.status === 'pending' && (
                  <div className="space-y-2 pt-2 border-t">
                    <Label className="text-sm">ملاحظة (اختياري)</Label>
                    <Textarea
                      placeholder="سبب القبول أو الرفض..."
                      rows={2}
                      value={reviewNote[p.id] || ''}
                      onChange={e => setReviewNote(prev => ({ ...prev, [p.id]: e.target.value }))}
                    />
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => review(p.id, 'approved')}
                        disabled={processing === p.id}
                      >
                        {processing === p.id ? 'جارٍ...' : '✅ قبول الدفعة'}
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => review(p.id, 'rejected')}
                        disabled={processing === p.id}
                      >
                        ❌ رفض
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
