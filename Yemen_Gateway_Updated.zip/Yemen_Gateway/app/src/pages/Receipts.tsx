import { useState, useEffect } from 'react';
import { API_BASE_URL } from '@/lib/constants';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';

interface Receipt {
  id: string;
  customer_name: string;
  customer_phone?: string;
  customer_email?: string;
  amount: number;
  status: string;
  created_at: string;
}

interface Customer {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
}

export default function ReceiptsPage() {
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [form, setForm] = useState({
    customer_name: '',
    customer_phone: '',
    customer_email: '',
    amount: 0,
  });

  const fetchReceipts = async () => {
    const token = localStorage.getItem('yg_token');
    if (!token) return;

    const res = await fetch(`${API_BASE_URL}/api/v1/receipts`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) setReceipts(data.data);
  };

  const fetchCustomers = async () => {
    const token = localStorage.getItem('yg_token');
    if (!token) return;

    const res = await fetch(`${API_BASE_URL}/api/v1/customers`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (data.success) setCustomers(data.data || []);
  };

  useEffect(() => {
    fetchReceipts();
    fetchCustomers();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('yg_token');
    if (!token) return;

    const res = await fetch(`${API_BASE_URL}/api/v1/receipts`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(form),
    });

    const data = await res.json();
    if (data.success) {
      setReceipts([...receipts, data.data]);
      setForm({ customer_name: '', customer_phone: '', customer_email: '', amount: 0 });
      setSelectedCustomer('');
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">إنشاء سند قبض جديد</h1>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <Label>اختر عميل</Label>
          <Select
            value={selectedCustomer}
            onValueChange={(value) => {
              setSelectedCustomer(value);
              const customer = customers.find((c) => c.id === value);
              if (customer) {
                setForm({
                  ...form,
                  customer_name: customer.name || '',
                  customer_phone: customer.phone || '',
                  customer_email: customer.email || '',
                });
              }
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="اختر عميل محفوظ" />
            </SelectTrigger>
            <SelectContent>
              {customers.map((customer) => (
                <SelectItem key={customer.id} value={customer.id}>
                  {customer.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>اسم العميل</Label>
          <Input
            value={form.customer_name}
            onChange={(e) => setForm({ ...form, customer_name: e.target.value })}
            required
          />
        </div>

        <div>
          <Label>الهاتف</Label>
          <Input
            value={form.customer_phone}
            onChange={(e) => setForm({ ...form, customer_phone: e.target.value })}
          />
        </div>

        <div>
          <Label>البريد الإلكتروني</Label>
          <Input
            value={form.customer_email}
            onChange={(e) => setForm({ ...form, customer_email: e.target.value })}
          />
        </div>

        <div>
          <Label>المبلغ</Label>
          <Input
            type="number"
            value={form.amount}
            onChange={(e) => setForm({ ...form, amount: parseFloat(e.target.value) })}
            required
          />
        </div>

        <Button type="submit">إنشاء سند قبض</Button>
      </form>

      <Separator className="my-6" />

      <h2 className="text-lg font-semibold mb-2">سندات القبض الحالية</h2>
      <div className="space-y-2">
        {receipts.map((receipt) => (
          <div
            key={receipt.id}
            className="border rounded p-3 flex justify-between items-center"
          >
            <div>
              <p>العميل: {receipt.customer_name}</p>
              <p>الهاتف: {receipt.customer_phone}</p>
              <p>البريد: {receipt.customer_email}</p>
              <p>المبلغ: {receipt.amount}</p>
              <p>الحالة: {receipt.status}</p>
            </div>
            <div className="space-x-2">
              <Button>تعديل</Button>
              <Button variant="destructive">حذف</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
