import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { API_BASE_URL } from '@/lib/constants';

function getHeaders() {
  return { Authorization: `Bearer ${localStorage.getItem('yg_token') || ''}` };
}

type PlanInfo = {
  plan_name: string;
  plan_slug: string;
  status: string;
  expires_at?: string;
  limits: {
    invoices_per_month: number;
    customers: number;
    api_calls_per_month: number;
    webhooks: number;
  };
  usage: {
    invoices_this_month: number;
    customers: number;
    api_calls_this_month: number;
    webhooks: number;
  };
};

const PLAN_COLORS: Record<string, string> = {
  free: 'secondary',
  starter: 'outline',
  business: 'default',
  enterprise: 'default',
};

function UsageBar({ label, used, limit }: { label: string; used: number; limit: number }) {
  const pct = limit === 0 ? 0 : Math.min(100, Math.round((used / limit) * 100));
  const isHigh = pct >= 80;
  const isFull = pct >= 100;
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span className={`font-medium ${isFull ? 'text-red-600' : isHigh ? 'text-orange-500' : ''}`}>
          {used.toLocaleString()} / {limit === -1 ? '∞' : limit.toLocaleString()}
        </span>
      </div>
      <Progress
        value={limit === -1 ? 10 : pct}
        className={`h-2 ${isFull ? '[&>div]:bg-red-500' : isHigh ? '[&>div]:bg-orange-400' : ''}`}
      />
    </div>
  );
}

export default function PlanStatusPage() {
  const [plan, setPlan] = useState<PlanInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/v1/subscription/status`, { headers: getHeaders() })
      .then(r => r.json())
      .then(d => {
        if (d.success) setPlan(d.data);
        else setError(d.error || 'فشل تحميل بيانات الخطة');
      })
      .catch(() => setError('تعذر الاتصال بالخادم'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="text-center py-16 text-muted-foreground">جارٍ التحميل...</div>;
  }

  if (error || !plan) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <p className="text-red-500">{error || 'لا توجد بيانات اشتراك'}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold">خطتك الحالية</h1>
        <p className="text-sm text-muted-foreground mt-1">مراقبة استخدامك وحدود الخطة</p>
      </div>

      {/* Plan summary */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">
              خطة {plan.plan_name}
            </CardTitle>
            <div className="flex gap-2">
              <Badge variant={(PLAN_COLORS[plan.plan_slug] || 'secondary') as 'default' | 'secondary' | 'outline' | 'destructive'}>
                {plan.plan_slug}
              </Badge>
              <Badge variant={plan.status === 'active' ? 'default' : 'destructive'}>
                {plan.status === 'active' ? 'نشط' : plan.status}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {plan.expires_at && (
            <p className="text-sm text-muted-foreground mb-4">
              تنتهي في: {new Date(plan.expires_at).toLocaleDateString('ar-YE')}
            </p>
          )}

          <div className="space-y-4">
            <UsageBar
              label="الفواتير هذا الشهر"
              used={plan.usage.invoices_this_month}
              limit={plan.limits.invoices_per_month}
            />
            <UsageBar
              label="العملاء"
              used={plan.usage.customers}
              limit={plan.limits.customers}
            />
            <UsageBar
              label="طلبات API هذا الشهر"
              used={plan.usage.api_calls_this_month}
              limit={plan.limits.api_calls_per_month}
            />
            <UsageBar
              label="Webhooks المفعّلة"
              used={plan.usage.webhooks}
              limit={plan.limits.webhooks}
            />
          </div>
        </CardContent>
      </Card>

      {/* Limits table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">حدود الخطة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3 text-sm">
            {[
              { label: 'الفواتير/شهر', val: plan.limits.invoices_per_month },
              { label: 'العملاء', val: plan.limits.customers },
              { label: 'طلبات API/شهر', val: plan.limits.api_calls_per_month },
              { label: 'Webhooks', val: plan.limits.webhooks },
            ].map(({ label, val }) => (
              <div key={label} className="bg-muted/40 rounded p-3">
                <p className="text-muted-foreground">{label}</p>
                <p className="font-bold text-lg">{val === -1 ? 'غير محدود' : val.toLocaleString()}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
