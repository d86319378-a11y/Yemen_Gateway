import { useEffect, useState } from 'react';
import { useParams } from 'react-router';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';

type InvoiceItem = {
  description: string;
  quantity: number;
  unit_price: number;
  total: number;
};

type Invoice = {
  id: string;
  number: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string;
  currency: string;
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  status: string;
  notes: string;
  created_at: string;
  due_date?: string;
  items: InvoiceItem[];
};

const PAYMENT_METHODS = [
  { value: 'kuraimi', label: 'كريمي (Kuraimi)' },
  { value: 'jawali', label: 'جوالي (Jawali)' },
  { value: 'onecash', label: 'ون كاش (OneCash)' },
  { value: 'bank_transfer', label: 'تحويل بنكي' },
  { value: 'cash', label: 'نقداً' },
];

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  draft: { label: 'مسودة', color: 'secondary' },
  pending: { label: 'في الانتظار', color: 'warning' },
  unpaid: { label: 'غير مدفوعة', color: 'destructive' },
  paid: { label: 'مدفوعة', color: 'default' },
  cancelled: { label: 'ملغاة', color: 'secondary' },
  expired: { label: 'منتهية الصلاحية', color: 'secondary' },
  pending_review: { label: 'قيد المراجعة', color: 'warning' },
};

export default function PublicPayPage() {
  const { invoiceId } = useParams<{ invoiceId: string }>();
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [form, setForm] = useState({
    sender_name: '',
    sender_phone: '',
    provider: '',
    reference: '',
    notes: '',
  });

  useEffect(() => {
    if (!invoiceId) return;
    fetch(`${API_URL}/api/v1/public/invoices/${invoiceId}`)
      .then(r => r.json())
      .then(data => {
        if (data.success) setInvoice(data.data);
        else setError(data.error || 'الفاتورة غير موجودة');
      })
      .catch(() => setError('تعذر تحميل الفاتورة'))
      .finally(() => setLoading(false));
  }, [invoiceId]);

  const handleSubmit = async () => {
    if (!form.sender_name || !form.sender_phone || !form.provider || !form.reference) {
      setError('يرجى تعبئة جميع الحقول المطلوبة');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch(`${API_URL}/api/v1/public/invoices/${invoiceId}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoice_id: invoiceId,
          provider: form.provider,
          sender_name: form.sender_name,
          sender_phone: form.sender_phone,
          amount: invoice?.total,
          currency: invoice?.currency,
          reference: form.reference,
          notes: form.notes,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSubmitted(true);
      } else {
        setError(data.error || 'فشل إرسال إثبات الدفع');
      }
    } catch {
      setError('حدث خطأ، يرجى المحاولة مجدداً');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-3"></div>
          <p className="text-gray-600">جارٍ تحميل الفاتورة...</p>
        </div>
      </div>
    );
  }

  if (error && !invoice) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50" dir="rtl">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-6 text-center">
            <div className="text-6xl mb-4">⚠️</div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">فاتورة غير موجودة</h2>
            <p className="text-gray-500">{error}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50" dir="rtl">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-8 text-center">
            <div className="text-6xl mb-4">✅</div>
            <h2 className="text-2xl font-bold text-green-700 mb-3">تم إرسال إثبات الدفع</h2>
            <p className="text-gray-600 mb-4">
              سيتم مراجعة طلبك من قبل التاجر وإخطارك بالنتيجة قريباً.
            </p>
            <Badge variant="outline" className="text-base px-4 py-1">
              الحالة: قيد المراجعة
            </Badge>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusInfo = STATUS_LABELS[invoice?.status || 'unpaid'] || STATUS_LABELS['unpaid'];
  const isPaid = invoice?.status === 'paid';
  const isCancelled = ['cancelled', 'expired'].includes(invoice?.status || '');

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4" dir="rtl">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-blue-700">بوابة يمن غيتواي</h1>
          <p className="text-gray-500 mt-1">صفحة سداد الفاتورة</p>
        </div>

        {/* Invoice Details */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">فاتورة رقم: {invoice?.number}</CardTitle>
              <Badge variant={statusInfo.color as "default" | "secondary" | "destructive" | "outline"}>
                {statusInfo.label}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span className="text-gray-500">العميل:</span>
                <p className="font-medium">{invoice?.customer_name}</p>
              </div>
              {invoice?.customer_phone && (
                <div>
                  <span className="text-gray-500">الهاتف:</span>
                  <p className="font-medium">{invoice?.customer_phone}</p>
                </div>
              )}
              <div>
                <span className="text-gray-500">تاريخ الإنشاء:</span>
                <p className="font-medium">
                  {invoice?.created_at ? new Date(invoice.created_at).toLocaleDateString('ar-YE') : '-'}
                </p>
              </div>
              {invoice?.due_date && (
                <div>
                  <span className="text-gray-500">تاريخ الاستحقاق:</span>
                  <p className="font-medium">
                    {new Date(invoice.due_date).toLocaleDateString('ar-YE')}
                  </p>
                </div>
              )}
            </div>

            <Separator />

            {/* Items */}
            <div>
              <h3 className="font-semibold mb-2">البنود:</h3>
              <div className="space-y-2">
                {invoice?.items?.map((item, i) => (
                  <div key={i} className="flex justify-between text-sm bg-gray-50 rounded p-2">
                    <span>{item.description} × {item.quantity}</span>
                    <span className="font-medium">{item.total.toLocaleString()} {invoice.currency}</span>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {/* Totals */}
            <div className="space-y-1 text-sm">
              {invoice?.tax !== 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-500">الضريبة:</span>
                  <span>{invoice?.tax.toLocaleString()} {invoice?.currency}</span>
                </div>
              )}
              {invoice?.discount !== 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-500">الخصم:</span>
                  <span className="text-green-600">- {invoice?.discount.toLocaleString()} {invoice?.currency}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-lg pt-2 border-t">
                <span>المبلغ الإجمالي:</span>
                <span className="text-blue-700">{invoice?.total.toLocaleString()} {invoice?.currency}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment instructions */}
        {!isPaid && !isCancelled && (
          <>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">طرق الدفع المتاحة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
                    <p className="font-semibold text-blue-800">💳 كريمي (Kuraimi)</p>
                    <p className="text-gray-600 mt-1">حوّل المبلغ ثم أدخل رقم العملية</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3 border border-green-200">
                    <p className="font-semibold text-green-800">📱 جوالي (Jawali)</p>
                    <p className="text-gray-600 mt-1">أرسل المبلغ عبر جوالي</p>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-3 border border-purple-200">
                    <p className="font-semibold text-purple-800">💰 ون كاش (OneCash)</p>
                    <p className="text-gray-600 mt-1">تحويل عبر ون كاش</p>
                  </div>
                  <div className="bg-orange-50 rounded-lg p-3 border border-orange-200">
                    <p className="font-semibold text-orange-800">🏦 تحويل بنكي</p>
                    <p className="text-gray-600 mt-1">تحويل مصرفي مباشر</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment Form */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">إثبات الدفع</CardTitle>
                <p className="text-sm text-gray-500">بعد تنفيذ الدفع، أدخل بيانات العملية للتحقق</p>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg p-3 text-sm">
                    {error}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label>اسم الدافع *</Label>
                    <Input
                      placeholder="الاسم الكامل"
                      value={form.sender_name}
                      onChange={e => setForm(f => ({ ...f, sender_name: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label>رقم الهاتف *</Label>
                    <Input
                      placeholder="07XXXXXXXX"
                      value={form.sender_phone}
                      onChange={e => setForm(f => ({ ...f, sender_phone: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <Label>طريقة الدفع *</Label>
                  <Select
                    value={form.provider}
                    onValueChange={v => setForm(f => ({ ...f, provider: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر طريقة الدفع" />
                    </SelectTrigger>
                    <SelectContent>
                      {PAYMENT_METHODS.map(m => (
                        <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1">
                  <Label>رقم العملية / الحوالة *</Label>
                  <Input
                    placeholder="مثال: TRX-123456"
                    value={form.reference}
                    onChange={e => setForm(f => ({ ...f, reference: e.target.value }))}
                  />
                </div>

                <div className="space-y-1">
                  <Label>ملاحظات (اختياري)</Label>
                  <Textarea
                    placeholder="أي معلومات إضافية..."
                    value={form.notes}
                    onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                    rows={3}
                  />
                </div>

                <Button
                  className="w-full"
                  size="lg"
                  onClick={handleSubmit}
                  disabled={submitting}
                >
                  {submitting ? 'جارٍ الإرسال...' : 'إرسال إثبات الدفع'}
                </Button>
              </CardContent>
            </Card>
          </>
        )}

        {isPaid && (
          <Card className="border-green-300 bg-green-50">
            <CardContent className="pt-6 text-center">
              <div className="text-4xl mb-2">✅</div>
              <p className="text-green-800 font-semibold text-lg">هذه الفاتورة مدفوعة بالفعل</p>
            </CardContent>
          </Card>
        )}

        {isCancelled && (
          <Card className="border-gray-300 bg-gray-50">
            <CardContent className="pt-6 text-center">
              <div className="text-4xl mb-2">🚫</div>
              <p className="text-gray-700 font-semibold text-lg">هذه الفاتورة ملغاة أو منتهية الصلاحية</p>
            </CardContent>
          </Card>
        )}

        <p className="text-center text-xs text-gray-400">
          مدعوم من بوابة يمن غيتواي · جميع المعلومات مشفرة وآمنة
        </p>
      </div>
    </div>
  );
}
