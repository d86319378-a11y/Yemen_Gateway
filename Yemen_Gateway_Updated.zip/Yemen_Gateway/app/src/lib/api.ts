// ===== Central API Helper =====
// يستخدم yg_token فقط في كل مكان

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';

function getToken(): string {
  return localStorage.getItem('yg_token') || '';
}

function getApiKey(): string {
  return localStorage.getItem('yg_api_key') || '';
}

type RequestOptions = {
  method?: string;
  body?: unknown;
  useApiKey?: boolean;  // إذا true يستخدم X-API-Key بدل Bearer
};

export async function apiRequest<T = unknown>(
  path: string,
  options: RequestOptions = {}
): Promise<T> {
  const { method = 'GET', body, useApiKey = false } = options;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (useApiKey) {
    headers['X-API-Key'] = getApiKey();
  } else {
    const token = getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }

  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }

  return data as T;
}

// ===== Typed helpers =====
export const api = {
  get: <T = unknown>(path: string, useApiKey = false) =>
    apiRequest<T>(path, { method: 'GET', useApiKey }),

  post: <T = unknown>(path: string, body: unknown, useApiKey = false) =>
    apiRequest<T>(path, { method: 'POST', body, useApiKey }),

  put: <T = unknown>(path: string, body: unknown, useApiKey = false) =>
    apiRequest<T>(path, { method: 'PUT', body, useApiKey }),

  delete: <T = unknown>(path: string, useApiKey = false) =>
    apiRequest<T>(path, { method: 'DELETE', useApiKey }),
};

export { API_URL, getToken, getApiKey };
