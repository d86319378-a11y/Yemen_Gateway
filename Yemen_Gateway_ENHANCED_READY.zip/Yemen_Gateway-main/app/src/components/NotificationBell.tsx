import { Link } from 'react-router';
import { Bell, CheckCheck, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { AppNotification } from '@/hooks/useNotifications';

type Props = {
  notifications: AppNotification[];
  unreadCount: number;
  onMarkRead: (id: string) => void;
  onMarkAllRead: () => void;
  onRemove: (id: string) => void;
  onClearAll: () => void;
};

export default function NotificationBell({
  notifications,
  unreadCount,
  onMarkRead,
  onMarkAllRead,
  onRemove,
  onClearAll,
}: Props) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" title="الإشعارات">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -left-1 h-5 min-w-5 px-1 text-[10px]">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent className="w-80" align="end">
        <DropdownMenuLabel className="flex items-center justify-between">
          <span>الإشعارات</span>
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" onClick={onMarkAllRead} title="تحديد الكل كمقروء">
              <CheckCheck className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={onClearAll} title="مسح الكل">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </DropdownMenuLabel>

        <DropdownMenuSeparator />

        {notifications.length === 0 ? (
          <div className="p-4 text-center text-sm text-muted-foreground">
            لا توجد إشعارات
          </div>
        ) : (
          notifications.slice(0, 6).map((notification) => (
            <DropdownMenuItem key={notification.id} className="items-start gap-2 p-3">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  {!notification.read && <span className="h-2 w-2 rounded-full bg-red-600" />}
                  <div className="font-medium">{notification.title}</div>
                </div>
                <div className="mt-1 text-xs text-muted-foreground">{notification.message}</div>
                {notification.href && (
                  <Link
                    to={notification.href}
                    className="mt-2 inline-block text-xs text-red-700"
                    onClick={() => onMarkRead(notification.id)}
                  >
                    فتح
                  </Link>
                )}
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.preventDefault();
                  onRemove(notification.id);
                }}
              >
                <X className="h-3 w-3" />
              </Button>
            </DropdownMenuItem>
          ))
        )}

        <DropdownMenuSeparator />

        <DropdownMenuItem asChild>
          <Link to="/notifications" className="justify-center text-center">
            عرض كل الإشعارات
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
