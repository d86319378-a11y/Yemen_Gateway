import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import {
  TrendingUp, DollarSign, Clock, FileText, Receipt,
  RefreshCw, Loader2, CheckCircle, BarChart3,
} from 'lucide-react';
import { API_BASE_URL } from '@/lib/constants';

function getToken() { return localStorage.getItem('yg_token') || ''; }

interface AdminStats {
  total_revenue: number;
  total_payments: number;
  pending_reviews: number;
  customers_count: number;
  invoices_count: number;
  paid_invoices: number;
  unpaid_invoices: number;
  total_vouchers: number;
  today_revenue: number;
  month_revenue: number;
}

interface DailyRevenue {
  date: string;
  revenue: number;
  count: number;
}

// Generate fallback data if API not ready
function mockRevenue(days: number): DailyRevenue[] {
  return Array.from({ length: days }, (_, i) => {
    const d = new Date(Date.now() - (days - 1 - i) * 86400000);
    return {
      date: d.toLocaleDateString('ar', { month: 'short', day: 'numeric' }),
      revenue: Math.floor(Math.random() * 80000 + 20000),
      count: Math.floor(Math.random() * 10 + 2),
    };
  });
}


export default function AdminDashboardProPage() {
  const [stats, setStats]     = useState<AdminStats | null>(null);
  const [revenue, setRevenue] = useState<DailyRevenue[]>([]);
  const [loading, setLoading] = useState(true);
  const [days, setDays]       = useState('30');
  const [refreshing, setRefreshing] = useState(false);

  const loadStats = async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/admin/dashboard/stats`, {
        headers: { Authorization: 'Bearer ' + getToken() },
      });
      const d = await res.json();
      if (d.success) setStats(d.data);
    } catch { /* use mock */ }
  };

  const loadRevenue = async (d: string) => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/admin/dashboard/revenue?days=${d}`, {
        headers: { Authorization: 'Bearer ' + getToken() },
      });
      const data = await res.json();
      if (data.success && data.data?.length) {
        setRevenue(data.data.map((r: DailyRevenue) => ({
          ...r,
          date: r.date ? new Date(r.date).toLocaleDateString('ar', { month: 'short', day: 'numeric' }) : r.date,
        })));
      } else {
        setRevenue(mockRevenue(parseInt(d)));
      }
    } catch {
      setRevenue(mockRevenue(parseInt(d)));
    }
  };

  useEffect(() => {
    Promise.all([loadStats(), loadRevenue(days)]).finally(() => setLoading(false));
  }, []);

  useEffect(() => { loadRevenue(days); }, [days]);

  const refresh = async () => {
    setRefreshing(true);
    await Promise.all([loadStats(), loadRevenue(days)]);
    setRefreshing(false);
  };

  const invoiceDistribution = stats ? [
    { name: 'مدفوعة',     value: stats.paid_invoices,   color: '#3b82f6' },
    { name: 'غير مدفوعة', value: stats.unpaid_invoices, color: '#f59e0b' },
    { name: 'ملغاة',      value: Math.max(0, stats.invoices_count - stats.paid_invoices - stats.unpaid_invoices), color: '#6b7280' },
  ] : [];

  const statCards = stats ? [
    { label: 'إجمالي الإيرادات',   value: stats.total_revenue.toLocaleString() + ' YER', icon: DollarSign,  color: 'text-blue-600',  bg: 'bg-blue-50',  sub: `اليوم: ${stats.today_revenue.toLocaleString()}` },
    { label: 'المدفوعات الكلية',   value: stats.total_payments.toString(),               icon: Receipt,     color: 'text-green-600', bg: 'bg-green-50', sub: `معلقة: ${stats.pending_reviews}` },
    { label: 'قيد المراجعة',       value: stats.pending_reviews.toString(),              icon: Clock,       color: 'text-amber-600', bg: 'bg-amber-50', sub: 'تحتاج مراجعة' },
    { label: 'عدد الفواتير',       value: stats.invoices_count.toString(),               icon: FileText,    color: 'text-purple-600',bg: 'bg-purple-50',sub: `مدفوعة: ${stats.paid_invoices}` },
    { label: 'إيرادات الشهر',      value: stats.month_revenue.toLocaleString() + ' YER', icon: TrendingUp,  color: 'text-rose-600',  bg: 'bg-rose-50',  sub: 'الشهر الحالي' },
    { label: 'السندات المُصدَرة',  value: stats.total_vouchers.toString(),               icon: BarChart3,   color: 'text-teal-600',  bg: 'bg-teal-50',  sub: 'قبض وصرف' },
  ] : [];

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">لوحة الإدارة المتقدمة</h1>
          <p className="text-muted-foreground text-sm mt-1">إحصاءات شاملة وتقارير الإيرادات</p>
        </div>
        <Button variant="outline" size="sm" onClick={refresh} disabled={refreshing}>
          <RefreshCw className={`h-4 w-4 ml-2 ${refreshing ? 'animate-spin' : ''}`} />
          تحديث
        </Button>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {statCards.map(s => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">{s.label}</p>
                    <p className={`text-xl font-bold mt-1 ${s.color}`}>{s.value}</p>
                    <p className="text-xs text-muted-foreground mt-1">{s.sub}</p>
                  </div>
                  <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${s.bg}`}>
                    <Icon className={`h-4.5 w-4.5 ${s.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Revenue Area Chart */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <CardTitle className="text-base">الإيرادات اليومية</CardTitle>
            </div>
            <Select value={days} onValueChange={setDays}>
              <SelectTrigger className="w-28 h-8 text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">7 أيام</SelectItem>
                <SelectItem value="14">14 يوم</SelectItem>
                <SelectItem value="30">30 يوم</SelectItem>
                <SelectItem value="60">60 يوم</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={revenue}>
              <defs>
                <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#3b82f6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fontSize: 10 }} interval={Math.floor(revenue.length / 7)} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={v => (v / 1000).toFixed(0) + 'k'} />
              <Tooltip
                formatter={(v: number) => [v.toLocaleString() + ' YER', 'الإيرادات']}
                contentStyle={{ fontSize: 12, direction: 'rtl' }}
              />
              <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} fill="url(#revenueGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Bar chart - invoice counts */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              <CardTitle className="text-sm">عدد الفواتير اليومياً</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={revenue.slice(-14)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 9 }} />
                <YAxis tick={{ fontSize: 9 }} />
                <Tooltip
                  formatter={(v: number) => [v, 'فاتورة']}
                  contentStyle={{ fontSize: 12, direction: 'rtl' }}
                />
                <Bar dataKey="count" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Pie chart - invoice status */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              <CardTitle className="text-sm">توزيع حالات الفواتير</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {invoiceDistribution.filter(d => d.value > 0).length > 0 ? (
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie
                    data={invoiceDistribution.filter(d => d.value > 0)}
                    cx="50%" cy="50%" innerRadius={45} outerRadius={72}
                    paddingAngle={3} dataKey="value"
                  >
                    {invoiceDistribution.filter(d => d.value > 0).map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: number) => [v, '']} contentStyle={{ fontSize: 12, direction: 'rtl' }} />
                  <Legend
                    formatter={(value) => <span style={{ fontSize: 12 }}>{value}</span>}
                    iconType="circle"
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[180px] text-muted-foreground text-sm">
                لا توجد بيانات كافية
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick links */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">إجراءات سريعة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: 'مراجعة المدفوعات', href: '/admin/payments', icon: Clock,       badge: stats?.pending_reviews },
              { label: 'إدارة الأسعار',    href: '/exchange-rates', icon: TrendingUp,  badge: null },
              { label: 'التحقق من الهاتف', href: '/phone-verify',   icon: CheckCircle, badge: null },
              { label: 'لوحة الإدارة',     href: '/admin',          icon: BarChart3,   badge: null },
            ].map(item => {
              const Icon = item.icon;
              return (
                <a
                  key={item.href}
                  href={item.href}
                  className="flex items-center gap-2 p-3 rounded-lg border hover:bg-accent hover:shadow-sm transition-all text-sm font-medium"
                >
                  <Icon className="h-4 w-4 text-primary shrink-0" />
                  <span className="flex-1">{item.label}</span>
                  {item.badge != null && item.badge > 0 && (
                    <Badge className="bg-amber-500 text-white text-xs px-1.5 py-0">{item.badge}</Badge>
                  )}
                </a>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
