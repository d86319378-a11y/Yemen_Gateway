import { useState } from 'react';
import { Link } from 'react-router';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useNotifications } from '@/hooks/useNotifications';
import {
  Bell, CheckCheck, Trash2, CheckCircle2, XCircle, Clock,
  FileText, Info, ExternalLink,
} from 'lucide-react';

const TYPE_CONFIG: Record<string, { icon: React.ElementType; color: string; bg: string; label: string }> = {
  payment_approved: { icon: CheckCircle2, color: 'text-green-600', bg: 'bg-green-50', label: 'قُبل الدفع' },
  payment_rejected: { icon: XCircle,       color: 'text-red-600',   bg: 'bg-red-50',   label: 'رُفض الدفع' },
  payment_pending:  { icon: Clock,          color: 'text-amber-600', bg: 'bg-amber-50', label: 'دفع معلق' },
  invoice_paid:     { icon: FileText,       color: 'text-blue-600',  bg: 'bg-blue-50',  label: 'فاتورة مدفوعة' },
  info:             { icon: Info,           color: 'text-gray-600',  bg: 'bg-gray-50',  label: 'معلومة' },
};

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)  return 'الآن';
  if (m < 60) return `منذ ${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `منذ ${h} ساعة`;
  const d = Math.floor(h / 24);
  return `منذ ${d} يوم`;
}

export default function NotificationsPage() {
  const { notifications, unreadCount, markRead, markAllRead, removeNotification, clearAll } = useNotifications();
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const visible = filter === 'unread' ? notifications.filter(n => !n.read) : notifications;

  return (
    <div className="space-y-6 max-w-3xl mx-auto" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Bell className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold">الإشعارات</h1>
            {unreadCount > 0 && (
              <Badge className="bg-primary text-white">{unreadCount}</Badge>
            )}
          </div>
          <p className="text-muted-foreground text-sm mt-1">جميع إشعارات حسابك</p>
        </div>
        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <Button variant="outline" size="sm" onClick={markAllRead}>
              <CheckCheck className="h-4 w-4 ml-1" />
              قراءة الكل
            </Button>
          )}
          {notifications.length > 0 && (
            <Button variant="ghost" size="sm" onClick={clearAll} className="text-red-600 hover:text-red-700">
              <Trash2 className="h-4 w-4 ml-1" />
              مسح الكل
            </Button>
          )}
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 border-b pb-2">
        {(['all', 'unread'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
              filter === f ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {f === 'all' ? `الكل (${notifications.length})` : `غير مقروءة (${unreadCount})`}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="font-semibold text-gray-700">
              {filter === 'unread' ? 'لا توجد إشعارات غير مقروءة' : 'لا توجد إشعارات'}
            </p>
            <p className="text-muted-foreground text-sm mt-1">ستظهر هنا إشعارات المدفوعات والفواتير</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {visible.map(n => {
            const cfg = TYPE_CONFIG[n.type] || TYPE_CONFIG.info;
            const Icon = cfg.icon;
            return (
              <div
                key={n.id}
                onClick={() => !n.read && markRead(n.id)}
                className={`flex items-start gap-4 p-4 rounded-xl border transition-all cursor-pointer hover:shadow-sm ${
                  n.read ? 'bg-white border-gray-100' : 'bg-blue-50/40 border-blue-100'
                }`}
              >
                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${cfg.bg}`}>
                  <Icon className={`h-5 w-5 ${cfg.color}`} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className={`font-semibold text-sm ${n.read ? 'text-gray-700' : 'text-gray-900'}`}>
                        {n.title}
                      </p>
                      <p className="text-sm text-muted-foreground mt-0.5 leading-relaxed">{n.message}</p>
                    </div>
                    {!n.read && (
                      <div className="h-2.5 w-2.5 rounded-full bg-primary shrink-0 mt-1" />
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="text-xs text-muted-foreground">{timeAgo(n.createdAt)}</span>
                    <Badge variant="outline" className="text-xs px-1.5 py-0">{cfg.label}</Badge>
                    {n.linkTo && (
                      <Link
                        to={n.linkTo}
                        onClick={e => e.stopPropagation()}
                        className="text-xs text-primary hover:underline flex items-center gap-1"
                      >
                        عرض <ExternalLink className="h-3 w-3" />
                      </Link>
                    )}
                  </div>
                </div>

                <button
                  onClick={e => { e.stopPropagation(); removeNotification(n.id); }}
                  className="shrink-0 p-1 rounded-md hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <XCircle className="h-4 w-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Summary stats */}
      {notifications.length > 0 && (
        <>
          <Separator />
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'إجمالي الإشعارات', value: notifications.length, color: 'text-gray-700' },
              { label: 'غير مقروءة',        value: unreadCount,          color: 'text-primary' },
              { label: 'مقروءة',            value: notifications.length - unreadCount, color: 'text-green-600' },
            ].map(s => (
              <Card key={s.label}>
                <CardContent className="pt-4 text-center">
                  <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
                  <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
