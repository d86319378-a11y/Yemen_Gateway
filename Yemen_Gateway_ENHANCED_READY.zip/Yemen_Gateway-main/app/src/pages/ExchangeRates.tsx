import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { RefreshCw, Loader2, TrendingUp, TrendingDown, DollarSign, Edit2, Check, X } from 'lucide-react';
import { API_BASE_URL } from '@/lib/constants';

const CURRENCIES = [
  { code: 'USD', name: 'دولار أمريكي',   flag: '🇺🇸', symbol: '$' },
  { code: 'SAR', name: 'ريال سعودي',    flag: '🇸🇦', symbol: '﷼' },
  { code: 'EUR', name: 'يورو',           flag: '🇪🇺', symbol: '€' },
  { code: 'AED', name: 'درهم إماراتي',  flag: '🇦🇪', symbol: 'د.إ' },
  { code: 'QAR', name: 'ريال قطري',     flag: '🇶🇦', symbol: 'ر.ق' },
  { code: 'KWD', name: 'دينار كويتي',   flag: '🇰🇼', symbol: 'د.ك' },
  { code: 'GBP', name: 'جنيه إسترليني', flag: '🇬🇧', symbol: '£' },
];

interface Rate {
  id: string;
  from_code: string;
  to_code: string;
  rate: number;
  source: string;
  created_at: string;
}

function getToken() { return localStorage.getItem('yg_token') || ''; }
function getApiKey() { return localStorage.getItem('yg_api_key') || ''; }

function generateMockHistory(base: number, days = 30) {
  return Array.from({ length: days }, (_, i) => {
    const date = new Date(Date.now() - (days - 1 - i) * 86400000);
    const variation = (Math.sin(i * 0.4) * 0.015 + (Math.random() - 0.5) * 0.01) * base;
    return {
      date: date.toLocaleDateString('ar', { month: 'short', day: 'numeric' }),
      rate: +(base + variation).toFixed(2),
    };
  });
}

export default function ExchangeRatesPage() {
  const [rates, setRates]           = useState<Record<string, Rate>>({});
  const [loading, setLoading]       = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selected, setSelected]     = useState('USD');
  const [history, setHistory]       = useState<{ date: string; rate: number }[]>([]);
  const [isAdmin, setIsAdmin]       = useState(false);
  const [editId, setEditId]         = useState<string | null>(null);
  const [editRate, setEditRate]     = useState('');
  const [saving, setSaving]         = useState(false);
  const [usdToYer, setUsdToYer]     = useState(0);
  const [sarToYer, setSarToYer]     = useState(0);

  const fetchRates = async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/currency/rates`, {
        headers: { 'X-API-Key': getApiKey(), 'Authorization': 'Bearer ' + getToken() },
      });
      const data = await res.json();
      if (data.success) {
        const map: Record<string, Rate> = {};
        Object.entries(data.data).forEach(([key, val]: any) => {
          const [from] = key.split('_');
          map[from] = { id: '', from_code: from, to_code: 'YER', rate: val.rate, source: '', created_at: val.updated_at };
        });
        setRates(map);
        setUsdToYer(map['USD']?.rate || 0);
        setSarToYer(map['SAR']?.rate || 0);
      }
    } catch {
      /* ignore */
    }
  };

  const fetchAdminRates = async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/admin/exchange-rates`, {
        headers: { 'Authorization': 'Bearer ' + getToken() },
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        const map: Record<string, Rate> = {};
        data.data.forEach((r: Rate) => { map[r.from_code] = r; });
        setRates(map);
        setIsAdmin(true);
        setUsdToYer(map['USD']?.rate || 0);
        setSarToYer(map['SAR']?.rate || 0);
      }
    } catch {
      setIsAdmin(false);
    }
  };

  const load = async () => {
    setLoading(true);
    await fetchAdminRates();
    if (!isAdmin) await fetchRates();
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    const r = rates[selected];
    if (r) setHistory(generateMockHistory(r.rate));
  }, [selected, rates]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const handleSaveRate = async (id: string) => {
    const newRate = parseFloat(editRate);
    if (!newRate || newRate <= 0) return;
    setSaving(true);
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/admin/exchange-rates/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + getToken() },
        body: JSON.stringify({ rate: newRate, source: 'manual' }),
      });
      const data = await res.json();
      if (data.success) {
        setEditId(null);
        await load();
      }
    } finally {
      setSaving(false);
    }
  };

  const selectedRate = rates[selected];
  const prevRate = selectedRate ? selectedRate.rate * 0.998 : 0;
  const change = selectedRate ? ((selectedRate.rate - prevRate) / prevRate * 100) : 0;

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">أسعار الصرف</h1>
          <p className="text-muted-foreground text-sm mt-1">أسعار صرف العملات مقابل الريال اليمني</p>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh} disabled={refreshing}>
          <RefreshCw className={`h-4 w-4 ml-2 ${refreshing ? 'animate-spin' : ''}`} />
          تحديث
        </Button>
      </div>

      {/* Dashboard widget */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-lg">🇺🇸</span>
              <span className="font-semibold text-blue-800">USD / YER</span>
            </div>
            <div className="text-3xl font-bold text-blue-900">{usdToYer.toLocaleString()}</div>
            <div className="text-xs text-blue-600 mt-1">ريال يمني لكل دولار</div>
          </CardContent>
        </Card>
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-lg">🇸🇦</span>
              <span className="font-semibold text-green-800">SAR / YER</span>
            </div>
            <div className="text-3xl font-bold text-green-900">{sarToYer.toLocaleString()}</div>
            <div className="text-xs text-green-600 mt-1">ريال يمني لكل ريال سعودي</div>
          </CardContent>
        </Card>
      </div>

      {/* Rates grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {CURRENCIES.map(cur => {
          const r = rates[cur.code];
          if (!r) return null;
          const active = selected === cur.code;
          return (
            <Card
              key={cur.code}
              className={`cursor-pointer transition-all hover:shadow-md ${active ? 'ring-2 ring-primary' : ''}`}
              onClick={() => setSelected(cur.code)}
            >
              <CardContent className="pt-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{cur.flag}</span>
                    <div>
                      <div className="font-bold text-sm">{cur.code} / YER</div>
                      <div className="text-xs text-muted-foreground">{cur.name}</div>
                    </div>
                  </div>
                  {isAdmin && !editId && (
                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={e => { e.stopPropagation(); setEditId(r.id); setEditRate(String(r.rate)); }}>
                      <Edit2 className="h-3.5 w-3.5" />
                    </Button>
                  )}
                </div>

                {editId === r.id ? (
                  <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
                    <Input value={editRate} onChange={e => setEditRate(e.target.value)} className="h-8 text-sm" type="number" />
                    <Button size="sm" className="h-8 px-2" onClick={() => handleSaveRate(r.id)} disabled={saving}>
                      {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 px-2" onClick={() => setEditId(null)}>
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-end justify-between">
                    <div>
                      <span className="text-2xl font-bold">{r.rate.toLocaleString()}</span>
                      <span className="text-sm text-muted-foreground mr-1">ر.ي</span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {r.source || 'central_bank'}
                    </Badge>
                  </div>
                )}

                <div className="text-xs text-muted-foreground mt-2">
                  آخر تحديث: {r.created_at ? new Date(r.created_at).toLocaleDateString('ar') : '—'}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Chart */}
      {selectedRate && (
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                <CardTitle className="text-base">
                  {CURRENCIES.find(c => c.code === selected)?.flag} سعر {selected} / YER — آخر 30 يوم
                </CardTitle>
              </div>
              <Select value={selected} onValueChange={setSelected}>
                <SelectTrigger className="w-28 h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map(c => (
                    <SelectItem key={c.code} value={c.code}>{c.flag} {c.code}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 mb-4">
              <div>
                <div className="text-2xl font-bold">{selectedRate.rate.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">السعر الحالي</div>
              </div>
              <div className={`flex items-center gap-1 text-sm font-semibold ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {change >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                {change >= 0 ? '+' : ''}{change.toFixed(2)}%
              </div>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} interval={4} />
                <YAxis tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
                <Tooltip
                  formatter={(v: number) => [v.toLocaleString() + ' YER', selected]}
                  contentStyle={{ fontSize: 12, direction: 'rtl' }}
                />
                <Line type="monotone" dataKey="rate" stroke="#3b82f6" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Converter */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            <CardTitle className="text-base">حاسبة تحويل العملات</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <CurrencyConverter rates={rates} currencies={CURRENCIES} />
        </CardContent>
      </Card>
    </div>
  );
}

function CurrencyConverter({ rates, currencies }: { rates: Record<string, any>; currencies: typeof CURRENCIES }) {
  const [amount, setAmount]     = useState('1000');
  const [fromCur, setFromCur]   = useState('USD');
  const [result, setResult]     = useState<number | null>(null);

  useEffect(() => {
    const a = parseFloat(amount);
    if (!a || !rates[fromCur]) { setResult(null); return; }
    setResult(a * rates[fromCur].rate);
  }, [amount, fromCur, rates]);

  return (
    <div className="flex flex-col sm:flex-row gap-4 items-end">
      <div className="flex-1 space-y-1">
        <Label className="text-sm">المبلغ</Label>
        <Input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="h-10" />
      </div>
      <div className="w-40 space-y-1">
        <Label className="text-sm">من</Label>
        <Select value={fromCur} onValueChange={setFromCur}>
          <SelectTrigger className="h-10">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {currencies.map(c => (
              <SelectItem key={c.code} value={c.code}>{c.flag} {c.code}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex-1">
        <Separator className="mb-2 hidden sm:block" />
        <div className="p-3 bg-primary/5 rounded-lg text-center">
          {result !== null ? (
            <>
              <div className="text-xl font-bold text-primary">{result.toLocaleString('ar', { maximumFractionDigits: 2 })}</div>
              <div className="text-sm text-muted-foreground">ريال يمني</div>
            </>
          ) : (
            <div className="text-muted-foreground text-sm">أدخل مبلغاً</div>
          )}
        </div>
      </div>
    </div>
  );
}
