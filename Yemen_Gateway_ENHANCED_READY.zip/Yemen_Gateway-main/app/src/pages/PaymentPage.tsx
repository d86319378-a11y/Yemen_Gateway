import { useState, useEffect } from 'react';
import { useParams } from 'react-router';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, CheckCircle2, FileText, QrCode, CreditCard, Phone, Building2, AlertCircle, ExternalLink } from 'lucide-react';
import { API_BASE_URL } from '@/lib/constants';

interface InvoiceItem {
  description: string;
  quantity: number;
  unit_price: number;
  total: number;
}

interface PublicInvoice {
  id: string;
  number: string;
  customer_name: string;
  customer_phone: string;
  currency: string;
  total: number;
  subtotal: number;
  tax: number;
  discount: number;
  status: string;
  notes: string;
  due_date: string | null;
  created_at: string;
  items: InvoiceItem[];
  qr_payload: string;
  pdf_url: string;
}

const STATUS_MAP: Record<string, { label: string; color: string }> = {
  unpaid: { label: 'غير مدفوعة', color: 'destructive' },
  paid:   { label: 'مدفوعة',    color: 'default' },
  cancelled: { label: 'ملغاة',  color: 'secondary' },
  pending: { label: 'معلقة',    color: 'outline' },
};

const PROVIDERS = [
  { value: 'kuraimi',    label: 'كريمي' },
  { value: 'jawali',     label: 'جوالي' },
  { value: 'onecash',    label: 'ون كاش' },
  { value: 'cac',        label: 'بنك CAC' },
  { value: 'tadhamon',   label: 'التضامن' },
  { value: 'cash',       label: 'نقد' },
  { value: 'bank',       label: 'تحويل بنكي' },
];

export default function PaymentPage() {
  const { id } = useParams<{ id: string }>();
  const [invoice, setInvoice] = useState<PublicInvoice | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const [form, setForm] = useState({
    provider: '',
    sender_name: '',
    sender_phone: '',
    amount: '',
    reference: '',
    screenshot_url: '',
  });

  useEffect(() => {
    if (!id) return;
    fetch(`${API_BASE_URL}/api/v1/public/invoices/${id}`)
      .then(r => r.json())
      .then(d => {
        if (d.success) setInvoice(d.data);
        else setError('الفاتورة غير موجودة');
      })
      .catch(() => setError('فشل في تحميل الفاتورة'))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (invoice) {
      setForm(f => ({ ...f, amount: String(invoice.total) }));
    }
  }, [invoice]);

  const handleSubmit = async () => {
    if (!form.provider || !form.sender_name || !form.sender_phone || !form.reference) {
      setSubmitError('يرجى تعبئة جميع الحقول المطلوبة');
      return;
    }
    setSubmitting(true);
    setSubmitError('');
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/public/invoices/${id}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          amount: parseFloat(form.amount) || invoice?.total,
          currency: invoice?.currency,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSubmitted(true);
      } else {
        setSubmitError(data.error || 'فشل في الإرسال');
      }
    } catch {
      setSubmitError('خطأ في الاتصال بالخادم');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
    </div>
  );

  if (error) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <Card className="max-w-md w-full text-center p-8">
        <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-gray-800 mb-2">فاتورة غير موجودة</h2>
        <p className="text-gray-500">{error}</p>
      </Card>
    </div>
  );

  if (!invoice) return null;

  const st = STATUS_MAP[invoice.status] || { label: invoice.status, color: 'secondary' };
  const isPayable = invoice.status === 'unpaid' || invoice.status === 'pending';

  if (submitted) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4" dir="rtl">
      <Card className="max-w-md w-full text-center p-8">
        <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800 mb-3">تم الإرسال بنجاح!</h2>
        <p className="text-gray-600 mb-2">تم استلام إثبات الدفع الخاص بك</p>
        <p className="text-gray-500 text-sm">سيتم مراجعته من قِبل الإدارة وسيُخطَر الطرف المعني بالموافقة</p>
        <Separator className="my-6" />
        <p className="text-sm text-gray-500">فاتورة رقم: <span className="font-mono font-bold">{invoice.number}</span></p>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 py-8 px-4" dir="rtl">
      <div className="max-w-2xl mx-auto space-y-4">

        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-2 mb-2">
            <span className="text-2xl">🇾🇪</span>
            <h1 className="text-xl font-bold text-gray-800">Yemen Gateway</h1>
          </div>
          <p className="text-gray-500 text-sm">بوابة الدفع الآمنة</p>
        </div>

        {/* Invoice Card */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-blue-600" />
                <CardTitle className="text-base">تفاصيل الفاتورة</CardTitle>
              </div>
              <Badge variant={st.color as any}>{st.label}</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><span className="text-gray-500">رقم الفاتورة</span><p className="font-mono font-bold">{invoice.number}</p></div>
              <div><span className="text-gray-500">اسم العميل</span><p className="font-semibold">{invoice.customer_name}</p></div>
              <div><span className="text-gray-500">التاريخ</span><p>{new Date(invoice.created_at).toLocaleDateString('ar')}</p></div>
              <div><span className="text-gray-500">العملة</span><p className="font-semibold">{invoice.currency}</p></div>
            </div>

            <Separator />

            {/* Items */}
            {invoice.items && invoice.items.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-semibold text-gray-700">البنود</p>
                {invoice.items.map((item, i) => (
                  <div key={i} className="flex justify-between text-sm bg-gray-50 rounded p-2">
                    <span className="text-gray-600">{item.description}</span>
                    <span className="font-semibold">{item.total.toLocaleString()} {invoice.currency}</span>
                  </div>
                ))}
              </div>
            )}

            <Separator />

            <div className="space-y-1 text-sm">
              <div className="flex justify-between text-gray-500"><span>المجموع الفرعي</span><span>{invoice.subtotal.toLocaleString()} {invoice.currency}</span></div>
              {invoice.tax > 0 && <div className="flex justify-between text-gray-500"><span>الضريبة</span><span>{invoice.tax.toLocaleString()} {invoice.currency}</span></div>}
              {invoice.discount > 0 && <div className="flex justify-between text-gray-500"><span>الخصم</span><span>- {invoice.discount.toLocaleString()} {invoice.currency}</span></div>}
              <div className="flex justify-between font-bold text-lg text-blue-700 pt-2 border-t"><span>الإجمالي</span><span>{invoice.total.toLocaleString()} {invoice.currency}</span></div>
            </div>

            {invoice.notes && (
              <Alert>
                <AlertDescription className="text-sm">{invoice.notes}</AlertDescription>
              </Alert>
            )}

            <div className="flex gap-2 pt-2">
              <Button variant="outline" size="sm" className="flex-1" onClick={() => window.open(invoice.pdf_url + '?print=1', '_blank')}>
                <ExternalLink className="h-4 w-4 ml-1" />
                طباعة PDF
              </Button>
              <Button variant="outline" size="sm" className="flex-1" onClick={() => window.open(invoice.pdf_url, '_blank')}>
                <FileText className="h-4 w-4 ml-1" />
                تحميل الفاتورة
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* QR Code Info */}
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100">
                <QrCode className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="font-semibold text-sm">رمز QR للتحقق</p>
                <p className="text-xs text-gray-500 font-mono mt-0.5 break-all">{invoice.qr_payload}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Instructions */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-base">تعليمات الدفع</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3 text-sm">
              {PROVIDERS.filter(p => p.value !== 'cash' && p.value !== 'bank').map(p => (
                <div key={p.value} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100">
                    <CreditCard className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-semibold">{p.label}</p>
                    <p className="text-gray-500 text-xs">أرسل المبلغ واحتفظ برقم العملية</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Payment Proof Form */}
        {isPayable && (
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-green-600" />
                <CardTitle className="text-base">إرسال إثبات الدفع</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {submitError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{submitError}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label>طريقة الدفع <span className="text-red-500">*</span></Label>
                <Select value={form.provider} onValueChange={v => setForm(f => ({ ...f, provider: v }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر طريقة الدفع" />
                  </SelectTrigger>
                  <SelectContent>
                    {PROVIDERS.map(p => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>اسم المُرسِل <span className="text-red-500">*</span></Label>
                  <Input placeholder="محمد أحمد" value={form.sender_name} onChange={e => setForm(f => ({ ...f, sender_name: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>رقم المُرسِل <span className="text-red-500">*</span></Label>
                  <Input placeholder="777123456" value={form.sender_phone} onChange={e => setForm(f => ({ ...f, sender_phone: e.target.value }))} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>المبلغ المُرسَل <span className="text-red-500">*</span></Label>
                  <Input type="number" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>رقم العملية / المرجع <span className="text-red-500">*</span></Label>
                  <Input placeholder="TXN123456" value={form.reference} onChange={e => setForm(f => ({ ...f, reference: e.target.value }))} />
                </div>
              </div>

              <div className="space-y-2">
                <Label>رابط لقطة الشاشة (اختياري)</Label>
                <Input placeholder="https://..." value={form.screenshot_url} onChange={e => setForm(f => ({ ...f, screenshot_url: e.target.value }))} />
                <p className="text-xs text-gray-400">ارفع لقطة الشاشة على Imgur أو أي موقع وضع الرابط هنا</p>
              </div>

              <Button className="w-full" onClick={handleSubmit} disabled={submitting}>
                {submitting ? <Loader2 className="h-4 w-4 animate-spin ml-2" /> : <CheckCircle2 className="h-4 w-4 ml-2" />}
                {submitting ? 'جاري الإرسال...' : 'إرسال إثبات الدفع'}
              </Button>
            </CardContent>
          </Card>
        )}

        {!isPayable && (
          <Card>
            <CardContent className="pt-6 text-center">
              <CheckCircle2 className="h-10 w-10 text-green-500 mx-auto mb-2" />
              <p className="font-semibold text-gray-700">
                {invoice.status === 'paid' ? 'هذه الفاتورة مدفوعة بالفعل' : 'هذه الفاتورة ملغاة'}
              </p>
            </CardContent>
          </Card>
        )}

        <p className="text-center text-xs text-gray-400 pb-4">
          مُعالَج بواسطة 🇾🇪 Yemen Gateway — بوابة المدفوعات اليمنية
        </p>
      </div>
    </div>
  );
}
