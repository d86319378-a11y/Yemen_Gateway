import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import {
  Webhook, Plus, Trash2, CheckCircle2, XCircle,
  Loader2, ChevronDown, ChevronUp,
} from 'lucide-react';
import { API_BASE_URL } from '@/lib/constants';

function getToken() { return localStorage.getItem('yg_token') || ''; }

const EVENTS = [
  'invoice.created', 'invoice.paid', 'invoice.cancelled',
  'payment.submitted', 'payment.approved', 'payment.rejected',
  'customer.created',
];

interface WebhookConfig {
  id: string;
  url: string;
  events: string;
  active: boolean;
  created_at: string;
}

interface DeliveryLog {
  id: string;
  webhook_id: string;
  event: string;
  status_code: number;
  success: boolean;
  attempted_at: string;
  response_body: string;
}

export default function WebhookTestingPage() {
  const [webhooks, setWebhooks]     = useState<WebhookConfig[]>([]);
  const [loading, setLoading]       = useState(true);
  const [creating, setCreating]     = useState(false);
  const [newUrl, setNewUrl]         = useState('');
  const [newEvents, setNewEvents]   = useState<string[]>([]);
  const [error, setError]           = useState('');
  const [success, setSuccess]       = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [logs, setLogs]             = useState<Record<string, DeliveryLog[]>>({});
  const [loadingLogs, setLoadingLogs] = useState<string | null>(null);

  const load = async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/webhooks`, {
        headers: { Authorization: 'Bearer ' + getToken() },
      });
      const d = await res.json();
      if (d.success) setWebhooks(d.data || []);
    } catch { /* ignore */ }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const toggleEvent = (e: string) =>
    setNewEvents(prev => prev.includes(e) ? prev.filter(x => x !== e) : [...prev, e]);

  const createWebhook = async () => {
    if (!newUrl || newEvents.length === 0) {
      setError('يلزم إدخال URL واختيار حدث واحد على الأقل');
      return;
    }
    setCreating(true); setError('');
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/webhooks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + getToken() },
        body: JSON.stringify({ url: newUrl, events: newEvents }),
      });
      const d = await res.json();
      if (d.success) {
        setSuccess('تم إنشاء الـ Webhook بنجاح');
        setNewUrl(''); setNewEvents([]);
        await load();
        setTimeout(() => setSuccess(''), 3000);
      } else {
        setError(d.error || 'فشل في الإنشاء');
      }
    } finally { setCreating(false); }
  };

  const deleteWebhook = async (id: string) => {
    if (!confirm('هل تريد حذف هذا الـ Webhook؟')) return;
    await fetch(`${API_BASE_URL}/api/v1/webhooks/${id}`, {
      method: 'DELETE',
      headers: { Authorization: 'Bearer ' + getToken() },
    });
    await load();
  };

  const loadLogs = async (id: string) => {
    if (expandedId === id) { setExpandedId(null); return; }
    setExpandedId(id);
    if (logs[id]) return;
    setLoadingLogs(id);
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/admin/webhooks/${id}/logs?limit=10`, {
        headers: { Authorization: 'Bearer ' + getToken() },
      });
      const d = await res.json();
      if (d.success) setLogs(prev => ({ ...prev, [id]: d.data || [] }));
    } finally { setLoadingLogs(null); }
  };

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Webhook className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">إدارة Webhooks</h1>
        </div>
        <p className="text-muted-foreground text-sm">تلقَّ إشعارات فورية عند وقوع الأحداث في حسابك</p>
      </div>

      {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
      {success && <Alert className="border-green-300 bg-green-50 text-green-800"><AlertDescription>{success}</AlertDescription></Alert>}

      {/* Create form */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Plus className="h-5 w-5 text-primary" />
            <CardTitle className="text-base">إضافة Webhook جديد</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Endpoint URL <span className="text-red-500">*</span></Label>
            <Input
              placeholder="https://yourapp.com/webhook"
              value={newUrl}
              onChange={e => setNewUrl(e.target.value)}
              dir="ltr"
              className="font-mono text-sm"
            />
          </div>

          <div className="space-y-2">
            <Label>الأحداث <span className="text-red-500">*</span></Label>
            <div className="flex flex-wrap gap-2">
              {EVENTS.map(e => (
                <button
                  key={e}
                  onClick={() => toggleEvent(e)}
                  className={`px-3 py-1.5 rounded-full text-xs font-mono border transition-all ${
                    newEvents.includes(e)
                      ? 'bg-primary text-white border-primary'
                      : 'bg-white text-muted-foreground border-gray-200 hover:border-primary'
                  }`}
                >
                  {e}
                </button>
              ))}
            </div>
            {newEvents.length > 0 && (
              <p className="text-xs text-muted-foreground">تم اختيار: {newEvents.length} حدث</p>
            )}
          </div>

          <Button onClick={createWebhook} disabled={creating}>
            {creating ? <Loader2 className="h-4 w-4 animate-spin ml-2" /> : <Plus className="h-4 w-4 ml-2" />}
            {creating ? 'جار الإنشاء...' : 'إنشاء Webhook'}
          </Button>
        </CardContent>
      </Card>

      {/* List */}
      <div className="space-y-3">
        <h2 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
          الـ Webhooks المُسجَّلة ({webhooks.length})
        </h2>

        {webhooks.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Webhook className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
              <p className="font-semibold text-gray-700">لا توجد Webhooks</p>
              <p className="text-sm text-muted-foreground mt-1">أضف Webhook لاستقبال الإشعارات</p>
            </CardContent>
          </Card>
        ) : (
          webhooks.map(wh => {
            const evts = wh.events.split(',').filter(Boolean);
            const expanded = expandedId === wh.id;
            return (
              <Card key={wh.id} className={expanded ? 'ring-1 ring-primary' : ''}>
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant={wh.active ? 'default' : 'secondary'}>
                          {wh.active ? 'نشط' : 'معطّل'}
                        </Badge>
                        <span className="font-mono text-sm text-blue-600 truncate">{wh.url}</span>
                      </div>
                      <div className="flex flex-wrap gap-1.5 mb-2">
                        {evts.map(e => (
                          <span key={e} className="px-2 py-0.5 bg-gray-100 rounded-full text-xs font-mono text-gray-600">{e}</span>
                        ))}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        أُنشئ: {new Date(wh.created_at).toLocaleDateString('ar')}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => loadLogs(wh.id)}>
                        {loadingLogs === wh.id
                          ? <Loader2 className="h-3 w-3 animate-spin" />
                          : expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                        <span className="mr-1">السجلات</span>
                      </Button>
                      <Button variant="ghost" size="sm" className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => deleteWebhook(wh.id)}>
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>

                  {/* Delivery logs */}
                  {expanded && (
                    <>
                      <Separator className="my-3" />
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-muted-foreground uppercase">سجلات التسليم</p>
                        {!logs[wh.id] ? (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground py-3">
                            <Loader2 className="h-4 w-4 animate-spin" />
                            تحميل السجلات...
                          </div>
                        ) : logs[wh.id].length === 0 ? (
                          <p className="text-sm text-muted-foreground py-3">لا توجد سجلات بعد</p>
                        ) : (
                          logs[wh.id].map(log => (
                            <div key={log.id} className="flex items-center justify-between py-2 border-b last:border-0 text-sm">
                              <div className="flex items-center gap-2">
                                {log.success
                                  ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500" />
                                  : <XCircle className="h-3.5 w-3.5 text-red-500" />}
                                <span className="font-mono text-xs bg-gray-100 px-2 py-0.5 rounded">{log.event}</span>
                              </div>
                              <div className="flex items-center gap-3">
                                <span className={`text-xs font-mono ${log.success ? 'text-green-600' : 'text-red-600'}`}>
                                  {log.status_code || 'ERR'}
                                </span>
                                <span className="text-xs text-muted-foreground">
                                  {new Date(log.attempted_at).toLocaleString('ar')}
                                </span>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Events reference */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">مرجع الأحداث المدعومة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
            {[
              { event: 'invoice.created',    desc: 'عند إنشاء فاتورة جديدة' },
              { event: 'invoice.paid',       desc: 'عند دفع فاتورة' },
              { event: 'invoice.cancelled',  desc: 'عند إلغاء فاتورة' },
              { event: 'payment.submitted',  desc: 'عند إرسال إثبات دفع' },
              { event: 'payment.approved',   desc: 'عند الموافقة على الدفع' },
              { event: 'payment.rejected',   desc: 'عند رفض الدفع' },
              { event: 'customer.created',   desc: 'عند إضافة عميل جديد' },
            ].map(e => (
              <div key={e.event} className="flex items-center gap-3 py-1.5">
                <span className="font-mono text-xs bg-gray-100 px-2 py-0.5 rounded w-40 shrink-0">{e.event}</span>
                <span className="text-muted-foreground text-xs">{e.desc}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
