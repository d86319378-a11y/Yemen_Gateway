import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  ArrowRight, Users, Phone, Mail, MapPin, FileText,
  CheckCircle2, Clock, Loader2, TrendingUp, AlertCircle, Calendar,
} from 'lucide-react';
import { API_BASE_URL } from '@/lib/constants';

function getToken() { return localStorage.getItem('yg_token') || ''; }

interface Customer {
  id: string; name: string; phone?: string; email?: string;
  address?: string; notes?: string; created_at: string;
}

interface CustomerStats {
  total_invoices: number;
  paid_invoices: number;
  unpaid_invoices: number;
  total_paid: number;
  outstanding_balance: number;
  last_payment_date?: string;
  last_invoice_date?: string;
}

interface Invoice {
  id: string; number: string; total: number; currency: string;
  status: string; created_at: string;
}

const STATUS_BADGE: Record<string, string> = {
  paid: 'bg-green-100 text-green-700',
  unpaid: 'bg-red-100 text-red-700',
  cancelled: 'bg-gray-100 text-gray-600',
  pending: 'bg-amber-100 text-amber-700',
};
const STATUS_LABEL: Record<string, string> = {
  paid: 'مدفوعة', unpaid: 'غير مدفوعة', cancelled: 'ملغاة', pending: 'معلقة',
};

export default function CustomerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [customer, setCustomer]   = useState<Customer | null>(null);
  const [stats, setStats]         = useState<CustomerStats | null>(null);
  const [invoices, setInvoices]   = useState<Invoice[]>([]);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState('');

  useEffect(() => {
    if (!id) return;
    const headers = { Authorization: 'Bearer ' + getToken() };
    Promise.all([
      fetch(`${API_BASE_URL}/api/v1/customers/${id}`, { headers }).then(r => r.json()),
      fetch(`${API_BASE_URL}/api/v1/customers/${id}/stats`, { headers }).then(r => r.json()),
      fetch(`${API_BASE_URL}/api/v1/customers/${id}/invoices`, { headers }).then(r => r.json()),
    ])
      .then(([cRes, sRes, iRes]) => {
        if (cRes.success) setCustomer(cRes.data);
        else setError('العميل غير موجود');
        if (sRes.success) setStats(sRes.data?.stats || sRes.data);
        if (iRes.success) setInvoices(iRes.data || []);
      })
      .catch(() => setError('فشل في تحميل البيانات'))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );

  if (error || !customer) return (
    <div className="text-center py-20">
      <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-3" />
      <p className="font-semibold text-gray-700">{error || 'العميل غير موجود'}</p>
      <Link to="/customers"><Button variant="outline" className="mt-4">العودة للعملاء</Button></Link>
    </div>
  );

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Link to="/customers" className="text-muted-foreground hover:text-foreground transition-colors">
          <ArrowRight className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold">{customer.name}</h1>
          <p className="text-muted-foreground text-sm">
            عميل منذ {new Date(customer.created_at).toLocaleDateString('ar')}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Customer info card */}
        <Card className="md:col-span-1">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-50">
                <Users className="h-5 w-5 text-red-600" />
              </div>
              <CardTitle className="text-base">بيانات العميل</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {customer.phone && (
              <div className="flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-muted-foreground shrink-0" />
                <span>{customer.phone}</span>
              </div>
            )}
            {customer.email && (
              <div className="flex items-center gap-2 text-sm">
                <Mail className="h-4 w-4 text-muted-foreground shrink-0" />
                <span>{customer.email}</span>
              </div>
            )}
            {customer.address && (
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
                <span>{customer.address}</span>
              </div>
            )}
            {customer.notes && (
              <>
                <Separator />
                <p className="text-xs text-muted-foreground">{customer.notes}</p>
              </>
            )}
          </CardContent>
        </Card>

        {/* CRM stats */}
        <Card className="md:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <CardTitle className="text-base">إحصاءات العميل</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                {
                  label: 'إجمالي الفواتير',
                  value: stats?.total_invoices ?? '—',
                  icon: FileText,
                  color: 'text-blue-600',
                  bg: 'bg-blue-50',
                },
                {
                  label: 'إجمالي المدفوع',
                  value: stats ? stats.total_paid.toLocaleString() + ' YER' : '—',
                  icon: CheckCircle2,
                  color: 'text-green-600',
                  bg: 'bg-green-50',
                },
                {
                  label: 'الرصيد المستحق',
                  value: stats ? stats.outstanding_balance.toLocaleString() + ' YER' : '—',
                  icon: AlertCircle,
                  color: stats?.outstanding_balance ? 'text-red-600' : 'text-gray-500',
                  bg: stats?.outstanding_balance ? 'bg-red-50' : 'bg-gray-50',
                },
                {
                  label: 'فواتير مدفوعة',
                  value: stats?.paid_invoices ?? '—',
                  icon: CheckCircle2,
                  color: 'text-green-600',
                  bg: 'bg-green-50',
                },
                {
                  label: 'فواتير غير مدفوعة',
                  value: stats?.unpaid_invoices ?? '—',
                  icon: Clock,
                  color: 'text-amber-600',
                  bg: 'bg-amber-50',
                },
                {
                  label: 'آخر دفعة',
                  value: stats?.last_payment_date
                    ? new Date(stats.last_payment_date).toLocaleDateString('ar')
                    : 'لا يوجد',
                  icon: Calendar,
                  color: 'text-purple-600',
                  bg: 'bg-purple-50',
                },
              ].map(s => {
                const Icon = s.icon;
                return (
                  <div key={s.label} className="flex items-center gap-3 p-3 rounded-lg border bg-white">
                    <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${s.bg}`}>
                      <Icon className={`h-4 w-4 ${s.color}`} />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{s.label}</p>
                      <p className={`font-bold text-sm ${s.color}`}>{s.value}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Invoices */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              <CardTitle className="text-base">الفواتير ({invoices.length})</CardTitle>
            </div>
            <Link to={`/invoices?customer=${encodeURIComponent(customer.name)}`}>
              <Button variant="outline" size="sm">عرض الكل</Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          {invoices.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">
              لا توجد فواتير لهذا العميل
            </div>
          ) : (
            <div className="space-y-2">
              {invoices.slice(0, 10).map(inv => (
                <div key={inv.id} className="flex items-center justify-between py-2.5 border-b last:border-0">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-sm text-muted-foreground">{inv.number}</span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_BADGE[inv.status] || 'bg-gray-100 text-gray-600'}`}>
                      {STATUS_LABEL[inv.status] || inv.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-semibold text-sm">
                      {inv.total.toLocaleString()} {inv.currency}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(inv.created_at).toLocaleDateString('ar')}
                    </span>
                    <Link to={`/invoices`}>
                      <Button variant="ghost" size="sm" className="h-7 text-xs">عرض</Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
