import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Phone, CheckCircle2, XCircle, Loader2, Signal, Globe, Copy } from 'lucide-react';
import { API_BASE_URL } from '@/lib/constants';

interface VerifyResult {
  id: string;
  phone: string;
  valid: boolean;
  carrier: string;
  type: string;
  formatted: string;
  country: string;
}

function getApiKey() { return localStorage.getItem('yg_api_key') || ''; }

const EXAMPLE_NUMBERS = [
  { number: '777123456', label: 'Yemen Mobile' },
  { number: '701234567', label: 'Sabafon' },
  { number: '721234567', label: 'MTN Yemen' },
  { number: '741234567', label: 'Y Telecom' },
  { number: '0112345678', label: 'TeleYemen (أرضي)' },
  { number: '999999999', label: 'رقم غير صالح' },
];

const CARRIER_COLORS: Record<string, string> = {
  'Yemen Mobile': 'bg-red-100 text-red-700 border-red-200',
  'Sabafon':      'bg-amber-100 text-amber-700 border-amber-200',
  'MTN Yemen':    'bg-yellow-100 text-yellow-700 border-yellow-200',
  'Y Telecom':    'bg-green-100 text-green-700 border-green-200',
  'TeleYemen':    'bg-blue-100 text-blue-700 border-blue-200',
};

export default function PhoneVerifyPage() {
  const [phone, setPhone]     = useState('');
  const [result, setResult]   = useState<VerifyResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');
  const [history, setHistory] = useState<VerifyResult[]>([]);

  const verify = async (phoneNum?: string) => {
    const target = phoneNum || phone;
    if (!target.trim()) return;
    setLoading(true);
    setError('');
    try {
      const apiKey = getApiKey();
      if (!apiKey) {
        setError('يلزم مفتاح API للاختبار — أنشئ مفتاحاً من صفحة "مفاتيح API"');
        return;
      }
      const res = await fetch(`${API_BASE_URL}/api/v1/phone/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey },
        body: JSON.stringify({ phone: target }),
      });
      const data = await res.json();
      if (data.success) {
        const r: VerifyResult = data.data;
        setResult(r);
        setHistory(prev => [r, ...prev.slice(0, 9)]);
      } else {
        setError(data.error || 'فشل في التحقق');
      }
    } catch {
      setError('خطأ في الاتصال بالخادم');
    } finally {
      setLoading(false);
    }
  };

  const copyFormatted = (text: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold">التحقق من الهاتف اليمني</h1>
        <p className="text-muted-foreground text-sm mt-1">
          تحقق من أرقام الهاتف اليمنية واكتشف شركة الاتصالات والصيغة الدولية
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-primary" />
                <CardTitle className="text-base">اختبار رقم الهاتف</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label>رقم الهاتف</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="777123456 أو 00967777123456"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && verify()}
                    className="font-mono"
                    dir="ltr"
                  />
                  <Button onClick={() => verify()} disabled={loading || !phone.trim()}>
                    {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'تحقق'}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  يقبل: 777123456 | 0777123456 | 00967777123456 | +967777123456
                </p>
              </div>

              <Separator />

              <div>
                <p className="text-sm font-semibold mb-3">أمثلة جاهزة</p>
                <div className="grid grid-cols-2 gap-2">
                  {EXAMPLE_NUMBERS.map(ex => (
                    <button
                      key={ex.number}
                      onClick={() => { setPhone(ex.number); verify(ex.number); }}
                      className="text-right p-2.5 rounded-lg border hover:bg-accent transition-colors"
                    >
                      <div className="font-mono text-sm font-bold">{ex.number}</div>
                      <div className="text-xs text-muted-foreground">{ex.label}</div>
                    </button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* API Reference */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">مرجع API</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="bg-muted rounded-md p-3 font-mono text-xs" dir="ltr">
                <div className="text-green-600 mb-1">POST /api/v1/phone/verify</div>
                <div className="text-muted-foreground">Headers: X-API-Key: your_key</div>
                <div className="mt-2 text-blue-600">{'{'}</div>
                <div className="mr-4">"phone": "777123456"</div>
                <div className="text-blue-600">{'}'}</div>
              </div>
              <div className="bg-muted rounded-md p-3 font-mono text-xs" dir="ltr">
                <div className="text-muted-foreground mb-1">Response:</div>
                <div className="text-blue-600">{'{'}</div>
                <div className="mr-4">"valid": true,</div>
                <div className="mr-4">"carrier": "Yemen Mobile",</div>
                <div className="mr-4">"type": "mobile",</div>
                <div className="mr-4">"formatted": "+967 777 123 456",</div>
                <div className="mr-4">"country": "YE"</div>
                <div className="text-blue-600">{'}'}</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Result */}
        <div className="space-y-4">
          {result && (
            <Card className={`border-2 ${result.valid ? 'border-green-300' : 'border-red-300'}`}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {result.valid
                      ? <CheckCircle2 className="h-5 w-5 text-green-500" />
                      : <XCircle className="h-5 w-5 text-red-500" />}
                    <CardTitle className="text-base">
                      {result.valid ? 'رقم صالح' : 'رقم غير صالح'}
                    </CardTitle>
                  </div>
                  <Badge className={CARRIER_COLORS[result.carrier] || 'bg-gray-100 text-gray-700 border-gray-200'}>
                    {result.carrier}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">الرقم المُدخَل</p>
                    <p className="font-mono font-bold text-sm">{result.phone}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">نوع الخط</p>
                    <Badge variant="outline">{result.type === 'mobile' ? '📱 موبايل' : '☎️ أرضي'}</Badge>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">شركة الاتصالات</p>
                    <div className="flex items-center gap-1.5">
                      <Signal className="h-3.5 w-3.5 text-primary" />
                      <span className="font-semibold text-sm">{result.carrier}</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">الدولة</p>
                    <div className="flex items-center gap-1.5">
                      <Globe className="h-3.5 w-3.5 text-primary" />
                      <span className="font-semibold text-sm">🇾🇪 اليمن</span>
                    </div>
                  </div>
                </div>

                {result.formatted && result.formatted !== result.phone && (
                  <>
                    <Separator />
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">الصيغة الدولية</p>
                      <div className="flex items-center justify-between bg-muted rounded-md px-3 py-2">
                        <span className="font-mono font-bold text-sm" dir="ltr">{result.formatted}</span>
                        <Button variant="ghost" size="sm" className="h-6 px-2" onClick={() => copyFormatted(result.formatted)}>
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          )}

          {/* History */}
          {history.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">سجل الاستعلامات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {history.map((h, i) => (
                    <div key={i} className="flex items-center justify-between py-1.5 border-b last:border-0">
                      <div className="flex items-center gap-2">
                        {h.valid
                          ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0" />
                          : <XCircle className="h-3.5 w-3.5 text-red-500 shrink-0" />}
                        <span className="font-mono text-sm">{h.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">{h.carrier}</span>
                        <button onClick={() => { setPhone(h.phone); verify(h.phone); }} className="text-xs text-primary hover:underline">
                          إعادة
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Carrier prefixes reference */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">بادئات شركات الاتصالات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {[
                  { name: 'Yemen Mobile', prefixes: '71, 73, 77', color: 'text-red-600' },
                  { name: 'Sabafon',      prefixes: '70, 78',     color: 'text-amber-600' },
                  { name: 'MTN Yemen',    prefixes: '72, 76',     color: 'text-yellow-600' },
                  { name: 'Y Telecom',    prefixes: '74, 75',     color: 'text-green-600' },
                  { name: 'TeleYemen',    prefixes: '01 (أرضي)',  color: 'text-blue-600' },
                ].map(c => (
                  <div key={c.name} className="flex items-center justify-between text-sm">
                    <span className={`font-semibold ${c.color}`}>{c.name}</span>
                    <span className="font-mono text-muted-foreground text-xs">{c.prefixes}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
