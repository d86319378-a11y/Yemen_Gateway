import { useEffect, useMemo, useState } from 'react';

export type AppNotification = {
  id: string;
  type: string;
  title: string;
  message: string;
  href?: string;
  linkTo?: string;
  read: boolean;
  created_at: string;
  createdAt: string;
};

const STORAGE_KEY = 'yg_notifications';

const seedNotifications: AppNotification[] = [
  {
    id: 'welcome',
    type: 'info',
    title: 'مرحباً بك',
    message: 'مركز الإشعارات جاهز لاستقبال تنبيهات الفواتير والمدفوعات.',
    read: false,
    created_at: new Date().toISOString(),
        createdAt: new Date().toISOString(),
  },
];

export function useNotifications() {
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : seedNotifications;
    } catch {
      return seedNotifications;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications));
  }, [notifications]);

  const unreadCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications],
  );

  const addNotification = (notification: Omit<AppNotification, 'id' | 'read' | 'created_at' | 'createdAt'>) => {
    setNotifications((prev) => [
      {
        ...notification,
        id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
        read: false,
        created_at: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const markRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const clearAll = () => setNotifications([]);

  return {
    notifications,
    unreadCount,
    addNotification,
    markRead,
    markAllRead,
    removeNotification,
    clearAll,
  };
}
