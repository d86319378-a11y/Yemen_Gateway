// invoicing_review_patch.go
// هذا الملف يُعرّف دالة مساعدة تُستخدم من invoicing.go بعد تعديله.
// بدلاً من تعديل invoicing.go مباشرةً، عدّل AdminReviewPaymentProof كما يلي:
//
// في AdminReviewPaymentProof، بعد السطر:
//   if req.Status == "approved" && h.webhookRepo != nil {
//
// أضف:
//   // Auto-create receipt voucher
//   invoice, _ := h.repo.GetInvoiceByID(proof.InvoiceID)
//   if invoice != nil {
//       h.repo.CreateAutoReceipt(proof, invoice)
//   }
//
// الكود الكامل للدالة المُحدَّثة موجود أدناه كمرجع.

package handlers

// AdminReviewPaymentProofFull — النسخة الكاملة المُحدَّثة من AdminReviewPaymentProof
// انسخ هذه الدالة واستبدل بها الدالة الموجودة في invoicing.go

/*
func (h *InvoicingHandler) AdminReviewPaymentProof(c *gin.Context) {
	proofID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "invalid proof id"})
		return
	}
	var req ReviewManualPaymentRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: err.Error()})
		return
	}
	proof, err := h.repo.ReviewPaymentProof(proofID, req.Status, req.Note)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "payment proof not found"})
		return
	}

	if req.Status == "approved" {
		invoice, iErr := h.repo.GetInvoiceByID(proof.InvoiceID)
		if iErr == nil {
			// 1. Auto-create receipt voucher
			h.repo.CreateAutoReceipt(proof, invoice)
			// 2. Fire webhook
			if h.webhookRepo != nil {
				FireWebhook(h.webhookRepo, invoice.UserID, "invoice.paid", invoice)
			}
		}
	}

	c.JSON(http.StatusOK, domain.APIResponse{Success: true, Data: proof})
}
*/
