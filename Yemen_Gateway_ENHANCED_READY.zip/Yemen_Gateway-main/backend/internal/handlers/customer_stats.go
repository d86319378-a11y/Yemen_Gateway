package handlers

// CustomerStatsHandler — إحصاءات العميل المُحسَّنة (المهمة ٧)
//
// Routes to add in main.go under `protected` group (JWT auth):
//   protected.GET("/customers/:id/stats", customerStatsHandler.GetStats)
//   protected.GET("/customers/:id/invoices", customerStatsHandler.GetInvoices)

import (
	"net/http"
	"yemenapi/internal/domain"
	"yemenapi/internal/repository"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type CustomerStatsHandler struct {
	customerRepo  *repository.CustomerRepository
	invoicingRepo *repository.InvoicingRepository
}

func NewCustomerStatsHandler(customerRepo *repository.CustomerRepository, invoicingRepo *repository.InvoicingRepository) *CustomerStatsHandler {
	return &CustomerStatsHandler{customerRepo: customerRepo, invoicingRepo: invoicingRepo}
}

// GetStats — GET /api/v1/customers/:id/stats
func (h *CustomerStatsHandler) GetStats(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "معرف غير صالح"})
		return
	}

	customer, err := h.customerRepo.GetByID(id)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "العميل غير موجود"})
		return
	}

	stats, err := h.invoicingRepo.GetCustomerStats(customer.Phone, customer.Email, currentUserID(c))
	if err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "فشل في جلب الإحصاءات"})
		return
	}

	c.JSON(http.StatusOK, domain.APIResponse{
		Success: true,
		Data: map[string]interface{}{
			"customer": customer,
			"stats":    stats,
		},
	})
}

// GetInvoices — GET /api/v1/customers/:id/invoices
func (h *CustomerStatsHandler) GetInvoices(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "معرف غير صالح"})
		return
	}

	customer, err := h.customerRepo.GetByID(id)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "العميل غير موجود"})
		return
	}

	invoices, err := h.invoicingRepo.GetInvoicesByCustomer(customer.Phone, customer.Email, currentUserID(c))
	if err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "فشل في جلب الفواتير"})
		return
	}

	c.JSON(http.StatusOK, domain.APIResponse{Success: true, Data: invoices})
}
