package handlers

// AdminProHandler — لوحة الإدارة المتقدمة (المهمة ١٠)
//
// Routes to add in main.go under `admin` group:
//   admin.GET("/dashboard/stats",       adminProHandler.DashboardStats)
//   admin.GET("/dashboard/revenue",     adminProHandler.RevenueChart)
//   admin.GET("/webhooks/:id/logs",     adminProHandler.WebhookLogs)

import (
	"net/http"
	"strconv"
	"yemenapi/internal/domain"
	"yemenapi/internal/repository"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type AdminProHandler struct {
	invoicingRepo *repository.InvoicingRepository
	webhookRepo   *repository.WebhookRepository
}

func NewAdminProHandler(invoicingRepo *repository.InvoicingRepository, webhookRepo *repository.WebhookRepository) *AdminProHandler {
	return &AdminProHandler{invoicingRepo: invoicingRepo, webhookRepo: webhookRepo}
}

// DashboardStats — GET /api/v1/admin/dashboard/stats
func (h *AdminProHandler) DashboardStats(c *gin.Context) {
	stats, err := h.invoicingRepo.GetAdminStats()
	if err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "فشل في جلب الإحصاءات"})
		return
	}
	c.JSON(http.StatusOK, domain.APIResponse{Success: true, Data: stats})
}

// RevenueChart — GET /api/v1/admin/dashboard/revenue?days=30
func (h *AdminProHandler) RevenueChart(c *gin.Context) {
	days, _ := strconv.Atoi(c.DefaultQuery("days", "30"))
	data, err := h.invoicingRepo.GetRevenueByDay(days)
	if err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "فشل في جلب بيانات الإيرادات"})
		return
	}
	c.JSON(http.StatusOK, domain.APIResponse{Success: true, Data: data})
}

// WebhookLogs — GET /api/v1/admin/webhooks/:id/logs
func (h *AdminProHandler) WebhookLogs(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "معرف غير صالح"})
		return
	}
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	logs, err := h.invoicingRepo.GetWebhookDeliveries(id, limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "فشل في جلب السجلات"})
		return
	}
	c.JSON(http.StatusOK, domain.APIResponse{Success: true, Data: logs})
}
