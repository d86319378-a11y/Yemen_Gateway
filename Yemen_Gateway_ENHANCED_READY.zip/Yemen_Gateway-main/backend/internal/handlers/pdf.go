package handlers

// PDF Generation Handler
// Uses Go's standard library + text/template to produce HTML that the browser prints as PDF.
// This approach requires zero extra Go dependencies (no wkhtmltopdf, no headless Chrome).
//
// How it works:
//   GET /api/v1/invoices/:id/pdf      → returns HTML page (Content-Type: text/html)
//   GET /api/v1/vouchers/:id/pdf      → same for vouchers
//
// The frontend opens the URL in a new tab; the user clicks Print → Save as PDF.
// This is the standard approach used by most SaaS products.
//
// Routes to register in main.go (under the `api` group that uses APIKeyAuth):
//   api.GET("/invoices/:id/pdf",  pdfHandler.InvoicePDF)
//   api.GET("/vouchers/:id/pdf",  pdfHandler.VoucherPDF)
//
// Also register under public (no auth) for the payment link page:
//   v1.GET("/public/invoices/:id/pdf", pdfHandler.InvoicePDFPublic)

import (
	"fmt"
	"html/template"
	"net/http"
	"strings"
	"time"
	"yemenapi/internal/domain"
	"yemenapi/internal/repository"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type PDFHandler struct {
	invoicingRepo *repository.InvoicingRepository
}

func NewPDFHandler(invoicingRepo *repository.InvoicingRepository) *PDFHandler {
	return &PDFHandler{invoicingRepo: invoicingRepo}
}

// InvoicePDF — authenticated route
func (h *PDFHandler) InvoicePDF(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "invalid id"})
		return
	}
	invoice, err := h.invoicingRepo.GetInvoice(currentUserID(c), id)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "invoice not found"})
		return
	}
	renderInvoiceHTML(c, invoice)
}

// InvoicePDFPublic — unauthenticated route (for /pay/:id page)
func (h *PDFHandler) InvoicePDFPublic(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "invalid id"})
		return
	}
	invoice, err := h.invoicingRepo.GetInvoiceByID(id)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "invoice not found"})
		return
	}
	renderInvoiceHTML(c, invoice)
}

// VoucherPDF — authenticated route
func (h *PDFHandler) VoucherPDF(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "invalid id"})
		return
	}
	vouchers, err := h.invoicingRepo.ListVouchers(currentUserID(c), "", 100)
	if err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "failed"})
		return
	}
	var found *domain.AccountingVoucher
	for i := range vouchers {
		if vouchers[i].ID == id {
			found = &vouchers[i]
			break
		}
	}
	if found == nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "voucher not found"})
		return
	}
	renderVoucherHTML(c, found)
}

// ─── HTML Templates ───────────────────────────────────────────────────────────

func renderInvoiceHTML(c *gin.Context, inv *domain.Invoice) {
	statusAr := map[string]string{
		"paid": "مدفوعة", "unpaid": "غير مدفوعة", "cancelled": "ملغاة", "pending": "معلقة",
	}
	statusColor := map[string]string{
		"paid": "#16a34a", "unpaid": "#dc2626", "cancelled": "#6b7280", "pending": "#d97706",
	}
	st := inv.Status
	rows := ""
	for i, item := range inv.Items {
		rows += fmt.Sprintf(`<tr>
			<td style="padding:8px 12px;border-bottom:1px solid #f1f5f9;text-align:right">%d</td>
			<td style="padding:8px 12px;border-bottom:1px solid #f1f5f9;text-align:right">%s</td>
			<td style="padding:8px 12px;border-bottom:1px solid #f1f5f9;text-align:center">%.2f</td>
			<td style="padding:8px 12px;border-bottom:1px solid #f1f5f9;text-align:center">%.2f</td>
			<td style="padding:8px 12px;border-bottom:1px solid #f1f5f9;text-align:left;font-weight:600">%.2f</td>
		</tr>`, i+1, template.HTMLEscapeString(item.Description), item.Quantity, item.UnitPrice, item.Total)
	}

	dueStr := "—"
	if inv.DueDate != nil {
		dueStr = inv.DueDate.Format("2006/01/02")
	}
	paidStr := "—"
	if inv.PaidAt != nil {
		paidStr = inv.PaidAt.Format("2006/01/02")
	}

	html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>فاتورة %s</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Arial,sans-serif;background:#f8fafc;color:#1e293b;font-size:14px;direction:rtl}
.page{max-width:794px;margin:0 auto;background:#fff;padding:40px 48px;min-height:1123px}
.header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:36px;padding-bottom:24px;border-bottom:2px solid #e2e8f0}
.logo-area h1{font-size:22px;font-weight:700;color:#1e40af;letter-spacing:-0.5px}
.logo-area p{color:#64748b;font-size:12px;margin-top:4px}
.inv-meta{text-align:left}
.inv-meta .number{font-size:18px;font-weight:700;color:#1e293b}
.inv-meta .date{color:#64748b;font-size:12px;margin-top:4px}
.status-badge{display:inline-block;padding:4px 14px;border-radius:20px;font-size:12px;font-weight:600;color:#fff;background:%s;margin-top:8px}
.section{margin-bottom:28px}
.section-title{font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;padding-bottom:6px;border-bottom:1px solid #f1f5f9}
.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.info-item label{font-size:11px;color:#94a3b8;display:block;margin-bottom:3px}
.info-item span{font-size:14px;color:#1e293b;font-weight:500}
table{width:100%%;border-collapse:collapse;margin-top:8px}
thead tr{background:#f8fafc}
thead th{padding:10px 12px;font-size:12px;font-weight:600;color:#64748b;text-align:right;border-bottom:2px solid #e2e8f0}
thead th:last-child{text-align:left}
thead th:nth-child(3),thead th:nth-child(4){text-align:center}
.totals{margin-top:20px;display:flex;justify-content:flex-end}
.totals-table{width:280px}
.totals-table tr td{padding:6px 12px;font-size:13px}
.totals-table tr td:first-child{color:#64748b;text-align:right}
.totals-table tr td:last-child{font-weight:600;text-align:left}
.total-row td{font-size:15px;font-weight:700;color:#1e40af;border-top:2px solid #e2e8f0;padding-top:10px}
.notes-box{background:#f8fafc;border-radius:8px;padding:14px 16px;font-size:13px;color:#475569;line-height:1.6}
.footer{margin-top:40px;padding-top:20px;border-top:1px solid #e2e8f0;text-align:center;color:#94a3b8;font-size:11px}
@media print{body{background:#fff}.page{padding:20px;min-height:auto}@page{margin:10mm}}
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div class="logo-area">
      <h1>🇾🇪 Yemen Gateway</h1>
      <p>بوابة اليمن للمدفوعات</p>
      <p style="margin-top:8px;color:#475569">support@yemengateway.dev</p>
    </div>
    <div class="inv-meta">
      <div class="number">%s</div>
      <div class="date">التاريخ: %s</div>
      <div class="date">الاستحقاق: %s</div>
      <div class="date">الدفع: %s</div>
      <div><span class="status-badge">%s</span></div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">بيانات العميل</div>
    <div class="info-grid">
      <div class="info-item"><label>اسم العميل</label><span>%s</span></div>
      <div class="info-item"><label>رقم الهاتف</label><span>%s</span></div>
      <div class="info-item"><label>البريد الإلكتروني</label><span>%s</span></div>
      <div class="info-item"><label>العملة</label><span>%s</span></div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">بنود الفاتورة</div>
    <table>
      <thead><tr>
        <th style="width:40px">#</th>
        <th>الوصف</th>
        <th style="width:80px;text-align:center">الكمية</th>
        <th style="width:100px;text-align:center">سعر الوحدة</th>
        <th style="width:110px;text-align:left">المجموع</th>
      </tr></thead>
      <tbody>%s</tbody>
    </table>
    <div class="totals">
      <table class="totals-table">
        <tr><td>المجموع الفرعي</td><td>%.2f %s</td></tr>
        <tr><td>الضريبة</td><td>%.2f %s</td></tr>
        <tr><td>الخصم</td><td>%.2f %s</td></tr>
        <tr class="total-row"><td>الإجمالي</td><td>%.2f %s</td></tr>
      </table>
    </div>
  </div>

  %s

  <div class="footer">
    <p>Yemen Gateway — منصة المدفوعات اليمنية المتكاملة</p>
    <p style="margin-top:4px">تم إنشاء هذه الفاتورة إلكترونياً وهي صالحة بدون توقيع</p>
  </div>
</div>
<script>
// Auto-trigger print dialog for PDF saving
window.addEventListener('load', function() {
  if (window.location.search.includes('print=1')) {
    setTimeout(function(){ window.print(); }, 500);
  }
});
</script>
</body>
</html>`,
		inv.Number,
		statusColor[st],
		inv.Number,
		inv.CreatedAt.Format("2006/01/02"),
		dueStr,
		paidStr,
		statusAr[st],
		template.HTMLEscapeString(inv.CustomerName),
		template.HTMLEscapeString(inv.CustomerPhone),
		template.HTMLEscapeString(inv.CustomerEmail),
		inv.Currency,
		template.HTML(rows),
		inv.Subtotal, inv.Currency,
		inv.Tax, inv.Currency,
		inv.Discount, inv.Currency,
		inv.Total, inv.Currency,
		notesSection(inv.Notes),
	)

	c.Header("Content-Type", "text/html; charset=utf-8")
	c.Header("Content-Disposition", fmt.Sprintf(`inline; filename="invoice-%s.html"`, inv.Number))
	c.String(http.StatusOK, html)
}

func renderVoucherHTML(c *gin.Context, v *domain.AccountingVoucher) {
	typeAr := map[string]string{"receipt": "سند قبض", "payment": "سند صرف"}
	typeColor := map[string]string{"receipt": "#16a34a", "payment": "#dc2626"}

	html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8"/>
<title>%s %s</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Arial,sans-serif;background:#f8fafc;color:#1e293b;font-size:14px;direction:rtl}
.page{max-width:600px;margin:40px auto;background:#fff;padding:40px 48px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,.08)}
.header{text-align:center;margin-bottom:32px;padding-bottom:20px;border-bottom:2px solid #e2e8f0}
.type-label{display:inline-block;padding:6px 20px;border-radius:20px;background:%s;color:#fff;font-size:14px;font-weight:700;margin-bottom:12px}
h1{font-size:20px;font-weight:700;color:#1e293b}
.number{font-size:13px;color:#64748b;margin-top:6px}
.field{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #f1f5f9}
.field:last-child{border-bottom:none}
.field label{color:#64748b;font-size:13px}
.field span{font-weight:600;color:#1e293b;font-size:14px}
.amount-row{background:#f8fafc;border-radius:8px;padding:16px;margin:20px 0;text-align:center}
.amount-row .amount{font-size:28px;font-weight:700;color:%s}
.amount-row .currency{font-size:14px;color:#64748b;margin-top:4px}
.footer{margin-top:32px;text-align:center;color:#94a3b8;font-size:11px;border-top:1px solid #e2e8f0;padding-top:16px}
.stamp-area{margin-top:32px;display:flex;justify-content:space-between;padding-top:20px;border-top:1px dashed #e2e8f0}
.stamp-box{text-align:center;width:45%%}
.stamp-box .label{font-size:11px;color:#94a3b8;margin-bottom:32px}
.stamp-box .line{border-top:1px solid #cbd5e1;margin-top:8px;padding-top:6px;font-size:11px;color:#94a3b8}
@media print{body{background:#fff}.page{box-shadow:none;margin:0;border-radius:0}@page{margin:10mm}}
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div class="type-label">%s</div>
    <h1>🇾🇪 Yemen Gateway</h1>
    <div class="number">رقم السند: %s</div>
    <div class="number">التاريخ: %s</div>
  </div>

  <div class="amount-row">
    <div class="amount">%.2f</div>
    <div class="currency">%s</div>
  </div>

  <div class="field"><label>اسم الطرف</label><span>%s</span></div>
  <div class="field"><label>رقم الهاتف</label><span>%s</span></div>
  <div class="field"><label>طريقة الدفع</label><span>%s</span></div>
  <div class="field"><label>المرجع</label><span>%s</span></div>
  <div class="field"><label>الوصف</label><span>%s</span></div>
  <div class="field"><label>الحالة</label><span>%s</span></div>

  <div class="stamp-area">
    <div class="stamp-box">
      <div class="label">توقيع المستلم</div>
      <div class="line">الاسم والتوقيع</div>
    </div>
    <div class="stamp-box">
      <div class="label">ختم الشركة</div>
      <div class="line">التاريخ والختم</div>
    </div>
  </div>

  <div class="footer">
    <p>Yemen Gateway — منصة المدفوعات اليمنية المتكاملة</p>
    <p style="margin-top:4px">هذا السند صادر إلكترونياً وصالح بدون توقيع ورقي</p>
  </div>
</div>
<script>
window.addEventListener('load', function() {
  if (window.location.search.includes('print=1')) {
    setTimeout(function(){ window.print(); }, 500);
  }
});
</script>
</body>
</html>`,
		typeAr[v.Type], v.Number,
		typeColor[v.Type],
		typeColor[v.Type],
		typeAr[v.Type],
		v.Number,
		v.CreatedAt.Format("2006/01/02"),
		v.Amount,
		v.Currency,
		template.HTMLEscapeString(v.PartyName),
		template.HTMLEscapeString(v.PartyPhone),
		methodAr(v.Method),
		template.HTMLEscapeString(v.Reference),
		template.HTMLEscapeString(v.Description),
		statusArVoucher(v.Status),
	)

	c.Header("Content-Type", "text/html; charset=utf-8")
	c.Header("Content-Disposition", fmt.Sprintf(`inline; filename="voucher-%s.html"`, v.Number))
	c.String(http.StatusOK, html)
}

func notesSection(notes string) string {
	if strings.TrimSpace(notes) == "" {
		return ""
	}
	return fmt.Sprintf(`<div class="section">
    <div class="section-title">ملاحظات</div>
    <div class="notes-box">%s</div>
  </div>`, template.HTMLEscapeString(notes))
}

func methodAr(m string) string {
	switch m {
	case "cash":
		return "نقد"
	case "wallet":
		return "محفظة إلكترونية"
	case "bank_transfer":
		return "تحويل بنكي"
	default:
		if m == "" {
			return "—"
		}
		return m
	}
}

func statusArVoucher(s string) string {
	switch s {
	case "issued":
		return "صادر"
	case "cancelled":
		return "ملغى"
	default:
		return s
	}
}

// Ensure time is imported (used in renderInvoiceHTML for format)
var _ = time.Now
