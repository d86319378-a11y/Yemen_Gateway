package handlers

import (
	"net/http"
	"strings"
	"yemenapi/internal/domain"
	"yemenapi/internal/repository"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

// PublicHandler serves unauthenticated pages — payment links, QR landing, etc.
type PublicHandler struct {
	invoicingRepo *repository.InvoicingRepository
}

func NewPublicHandler(invoicingRepo *repository.InvoicingRepository) *PublicHandler {
	return &PublicHandler{invoicingRepo: invoicingRepo}
}

// GetPublicInvoice — GET /api/v1/public/invoices/:id
// Returns invoice info needed for the public payment page (no auth).
func (h *PublicHandler) GetPublicInvoice(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "معرف الفاتورة غير صالح"})
		return
	}
	invoice, err := h.invoicingRepo.GetInvoiceByID(id)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "الفاتورة غير موجودة"})
		return
	}
	baseURL := getBaseURL(c)
	c.JSON(http.StatusOK, domain.APIResponse{
		Success: true,
		Data: map[string]interface{}{
			"id":             invoice.ID,
			"number":         invoice.Number,
			"customer_name":  invoice.CustomerName,
			"customer_phone": invoice.CustomerPhone,
			"currency":       invoice.Currency,
			"total":          invoice.Total,
			"subtotal":       invoice.Subtotal,
			"tax":            invoice.Tax,
			"discount":       invoice.Discount,
			"status":         invoice.Status,
			"notes":          invoice.Notes,
			"due_date":       invoice.DueDate,
			"created_at":     invoice.CreatedAt,
			"items":          invoice.Items,
			"qr_payload":     buildQRPayload(invoice),
			"pdf_url":        baseURL + "/api/v1/public/invoices/" + invoice.ID.String() + "/pdf",
		},
	})
}

// SubmitPublicPaymentProof — POST /api/v1/public/invoices/:id/pay
// Allows anyone with the invoice link to submit a payment proof without login.
type PublicPaymentRequest struct {
	Provider      string  `json:"provider" binding:"required"`
	SenderName    string  `json:"sender_name" binding:"required"`
	SenderPhone   string  `json:"sender_phone" binding:"required"`
	Amount        float64 `json:"amount" binding:"required,gt=0"`
	Currency      string  `json:"currency"`
	Reference     string  `json:"reference" binding:"required"`
	ScreenshotURL string  `json:"screenshot_url"`
}

func (h *PublicHandler) SubmitPublicPaymentProof(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "معرف الفاتورة غير صالح"})
		return
	}

	invoice, err := h.invoicingRepo.GetInvoiceByID(id)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "الفاتورة غير موجودة"})
		return
	}
	if invoice.Status == "paid" {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "هذه الفاتورة مدفوعة مسبقاً"})
		return
	}
	if invoice.Status == "cancelled" {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "هذه الفاتورة ملغاة"})
		return
	}

	var req PublicPaymentRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: err.Error()})
		return
	}

	currency := strings.ToUpper(req.Currency)
	if currency == "" {
		currency = invoice.Currency
	}

	proof := &domain.ManualPaymentProof{
		ID:            uuid.New(),
		UserID:        invoice.UserID, // owner of the invoice
		InvoiceID:     id,
		Provider:      req.Provider,
		SenderName:    req.SenderName,
		SenderPhone:   req.SenderPhone,
		Amount:        req.Amount,
		Currency:      currency,
		Reference:     req.Reference,
		ScreenshotURL: req.ScreenshotURL,
		Status:        "pending",
	}

	if err := h.invoicingRepo.CreatePaymentProof(proof); err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "فشل في إرسال إثبات الدفع"})
		return
	}

	c.JSON(http.StatusCreated, domain.APIResponse{
		Success: true,
		Data: map[string]interface{}{
			"message":    "تم استلام إثبات الدفع وهو قيد المراجعة",
			"proof_id":   proof.ID,
			"status":     "pending",
			"invoice_id": id,
		},
	})
}
