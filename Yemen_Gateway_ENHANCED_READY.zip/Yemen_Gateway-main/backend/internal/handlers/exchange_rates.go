package handlers

// ExchangeRateAdminHandler — إدارة أسعار الصرف من لوحة الأدمن
//
// Routes to add in main.go under the `admin` group:
//   admin.POST("/exchange-rates",        exchangeRateHandler.Create)
//   admin.PUT("/exchange-rates/:id",     exchangeRateHandler.Update)
//   admin.GET("/exchange-rates",         exchangeRateHandler.List)
//
// Public/API routes (already exist via CurrencyHandler, no change needed):
//   GET /api/v1/currency/rates
//   GET /api/v1/currency/history

import (
	"net/http"
	"strings"
	"time"
	"yemenapi/internal/domain"
	"yemenapi/internal/repository"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type ExchangeRateHandler struct {
	repo *repository.CurrencyRepository
}

func NewExchangeRateHandler(repo *repository.CurrencyRepository) *ExchangeRateHandler {
	return &ExchangeRateHandler{repo: repo}
}

var supportedCurrencies = map[string]bool{
	"USD": true, "SAR": true, "EUR": true,
	"AED": true, "QAR": true, "KWD": true, "GBP": true,
}

type CreateRateRequest struct {
	FromCode string  `json:"from_code" binding:"required"`
	ToCode   string  `json:"to_code" binding:"required"`
	Rate     float64 `json:"rate" binding:"required,gt=0"`
	Source   string  `json:"source"`
}

type UpdateRateRequest struct {
	Rate   float64 `json:"rate" binding:"required,gt=0"`
	Source string  `json:"source"`
}

// List — GET /api/v1/admin/exchange-rates
func (h *ExchangeRateHandler) List(c *gin.Context) {
	rates, err := h.repo.GetAllRates()
	if err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "فشل في جلب الأسعار"})
		return
	}
	c.JSON(http.StatusOK, domain.APIResponse{Success: true, Data: rates})
}

// Create — POST /api/v1/admin/exchange-rates
func (h *ExchangeRateHandler) Create(c *gin.Context) {
	var req CreateRateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: err.Error()})
		return
	}

	req.FromCode = strings.ToUpper(req.FromCode)
	req.ToCode = strings.ToUpper(req.ToCode)

	if !supportedCurrencies[req.FromCode] {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "عملة المصدر غير مدعومة: " + req.FromCode})
		return
	}

	source := req.Source
	if source == "" {
		source = "manual"
	}

	rate := &domain.CurrencyRate{
		ID:        uuid.New(),
		FromCode:  req.FromCode,
		ToCode:    req.ToCode,
		Rate:      req.Rate,
		Source:    source,
		Date:      time.Now(),
		CreatedAt: time.Now(),
	}

	if err := h.repo.CreateRate(rate); err != nil {
		c.JSON(http.StatusInternalServerError, domain.APIResponse{Success: false, Error: "فشل في إنشاء السعر"})
		return
	}

	c.JSON(http.StatusCreated, domain.APIResponse{Success: true, Data: rate})
}

// Update — PUT /api/v1/admin/exchange-rates/:id
func (h *ExchangeRateHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: "معرف غير صالح"})
		return
	}

	var req UpdateRateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, domain.APIResponse{Success: false, Error: err.Error()})
		return
	}

	source := req.Source
	if source == "" {
		source = "manual"
	}

	rate, err := h.repo.UpdateRateByID(id, req.Rate, source)
	if err != nil {
		c.JSON(http.StatusNotFound, domain.APIResponse{Success: false, Error: "السعر غير موجود"})
		return
	}

	c.JSON(http.StatusOK, domain.APIResponse{Success: true, Data: rate})
}
