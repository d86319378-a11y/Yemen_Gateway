package repository

// invoicing_extended.go — دوال إضافية لـ InvoicingRepository
// لا تعدّل invoicing.go الأصلي — فقط أضف هذا الملف.

import (
	"fmt"
	"time"
	"yemenapi/internal/domain"

	"github.com/google/uuid"
)

// CustomerStats — إحصاءات مُجمَّعة لعميل واحد
type CustomerStats struct {
	TotalInvoices      int64      `json:"total_invoices"`
	PaidInvoices       int64      `json:"paid_invoices"`
	UnpaidInvoices     int64      `json:"unpaid_invoices"`
	TotalPaid          float64    `json:"total_paid"`
	OutstandingBalance float64    `json:"outstanding_balance"`
	LastPaymentDate    *time.Time `json:"last_payment_date,omitempty"`
	LastInvoiceDate    *time.Time `json:"last_invoice_date,omitempty"`
}

// GetCustomerStats — يجمع إحصاءات عميل بالهاتف أو الإيميل
func (r *InvoicingRepository) GetCustomerStats(phone, email string, userID uuid.UUID) (*CustomerStats, error) {
	stats := &CustomerStats{}

	q := r.db.Model(&domain.Invoice{}).Where("user_id = ?", userID)
	if phone != "" && email != "" {
		q = q.Where("(customer_phone = ? OR customer_email = ?)", phone, email)
	} else if phone != "" {
		q = q.Where("customer_phone = ?", phone)
	} else if email != "" {
		q = q.Where("customer_email = ?", email)
	}

	q.Count(&stats.TotalInvoices)

	r.db.Model(&domain.Invoice{}).
		Where("user_id = ? AND status = 'paid' AND (customer_phone = ? OR customer_email = ?)", userID, phone, email).
		Count(&stats.PaidInvoices)

	r.db.Model(&domain.Invoice{}).
		Where("user_id = ? AND status = 'unpaid' AND (customer_phone = ? OR customer_email = ?)", userID, phone, email).
		Count(&stats.UnpaidInvoices)

	r.db.Model(&domain.Invoice{}).
		Where("user_id = ? AND status = 'paid' AND (customer_phone = ? OR customer_email = ?)", userID, phone, email).
		Select("COALESCE(SUM(total), 0)").Scan(&stats.TotalPaid)

	r.db.Model(&domain.Invoice{}).
		Where("user_id = ? AND status = 'unpaid' AND (customer_phone = ? OR customer_email = ?)", userID, phone, email).
		Select("COALESCE(SUM(total), 0)").Scan(&stats.OutstandingBalance)

	var lastPaid domain.Invoice
	if err := r.db.Where("user_id = ? AND status = 'paid' AND (customer_phone = ? OR customer_email = ?)", userID, phone, email).
		Order("paid_at DESC").First(&lastPaid).Error; err == nil {
		stats.LastPaymentDate = lastPaid.PaidAt
	}

	var lastInvoice domain.Invoice
	if err := r.db.Where("user_id = ? AND (customer_phone = ? OR customer_email = ?)", userID, phone, email).
		Order("created_at DESC").First(&lastInvoice).Error; err == nil {
		t := lastInvoice.CreatedAt
		stats.LastInvoiceDate = &t
	}

	return stats, nil
}

// GetInvoicesByCustomer — فواتير عميل واحد
func (r *InvoicingRepository) GetInvoicesByCustomer(phone, email string, userID uuid.UUID) ([]domain.Invoice, error) {
	var invoices []domain.Invoice
	err := r.db.Preload("Items").
		Where("user_id = ? AND (customer_phone = ? OR customer_email = ?)", userID, phone, email).
		Order("created_at DESC").
		Limit(50).
		Find(&invoices).Error
	return invoices, err
}

// CreateAutoReceipt — ينشئ سند قبض تلقائياً عند الموافقة على سند الدفع
func (r *InvoicingRepository) CreateAutoReceipt(proof *domain.ManualPaymentProof, invoice *domain.Invoice) (*domain.AccountingVoucher, error) {
	now := time.Now()
	voucher := &domain.AccountingVoucher{
		ID:               uuid.New(),
		UserID:           invoice.UserID,
		Number:           r.NextNumber("RCPT"),
		Type:             "receipt",
		PartyName:        proof.SenderName,
		PartyPhone:       proof.SenderPhone,
		Amount:           proof.Amount,
		Currency:         proof.Currency,
		Method:           proof.Provider,
		Reference:        proof.Reference,
		Description:      "سند قبض تلقائي - فاتورة رقم " + invoice.Number,
		Status:           "issued",
		RelatedInvoiceID: &invoice.ID,
		CreatedAt:        now,
		UpdatedAt:        now,
	}
	if err := r.db.Create(voucher).Error; err != nil {
		return nil, err
	}
	return voucher, nil
}

// WebhookDeliveryLog — يُعيد سجلات التسليم لـ webhook معيّن
func (r *InvoicingRepository) GetWebhookDeliveries(webhookID uuid.UUID, limit int) ([]domain.WebhookDelivery, error) {
	if limit <= 0 {
		limit = 20
	}
	var deliveries []domain.WebhookDelivery
	err := r.db.Where("webhook_id = ?", webhookID).
		Order("attempted_at DESC").
		Limit(limit).
		Find(&deliveries).Error
	return deliveries, err
}

// GetAdminDashboardStats — إحصاءات شاملة للأدمن
type AdminDashboardStats struct {
	TotalRevenue   float64 `json:"total_revenue"`
	TotalPayments  int64   `json:"total_payments"`
	PendingReviews int64   `json:"pending_reviews"`
	CustomersCount int64   `json:"customers_count"`
	InvoicesCount  int64   `json:"invoices_count"`
	PaidInvoices   int64   `json:"paid_invoices"`
	UnpaidInvoices int64   `json:"unpaid_invoices"`
	TotalVouchers  int64   `json:"total_vouchers"`
	TodayRevenue   float64 `json:"today_revenue"`
	MonthRevenue   float64 `json:"month_revenue"`
}

func (r *InvoicingRepository) GetAdminStats() (*AdminDashboardStats, error) {
	stats := &AdminDashboardStats{}
	now := time.Now()
	todayStart := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())
	monthStart := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, now.Location())

	r.db.Model(&domain.Invoice{}).Where("status = 'paid'").Select("COALESCE(SUM(total), 0)").Scan(&stats.TotalRevenue)
	r.db.Model(&domain.Invoice{}).Count(&stats.InvoicesCount)
	r.db.Model(&domain.Invoice{}).Where("status = 'paid'").Count(&stats.PaidInvoices)
	r.db.Model(&domain.Invoice{}).Where("status = 'unpaid'").Count(&stats.UnpaidInvoices)
	r.db.Model(&domain.ManualPaymentProof{}).Count(&stats.TotalPayments)
	r.db.Model(&domain.ManualPaymentProof{}).Where("status = 'pending'").Count(&stats.PendingReviews)
	r.db.Model(&domain.AccountingVoucher{}).Count(&stats.TotalVouchers)
	r.db.Model(&domain.Invoice{}).Where("status = 'paid' AND paid_at >= ?", todayStart).Select("COALESCE(SUM(total), 0)").Scan(&stats.TodayRevenue)
	r.db.Model(&domain.Invoice{}).Where("status = 'paid' AND paid_at >= ?", monthStart).Select("COALESCE(SUM(total), 0)").Scan(&stats.MonthRevenue)

	return stats, nil
}

// GetRevenueByDay — إيرادات آخر N يوم (للرسم البياني)
type DailyRevenue struct {
	Date    string  `json:"date"`
	Revenue float64 `json:"revenue"`
	Count   int64   `json:"count"`
}

func (r *InvoicingRepository) GetRevenueByDay(days int) ([]DailyRevenue, error) {
	if days <= 0 || days > 90 {
		days = 30
	}
	var result []DailyRevenue
	query := fmt.Sprintf(`
		SELECT
			TO_CHAR(paid_at, 'YYYY-MM-DD') as date,
			COALESCE(SUM(total), 0) as revenue,
			COUNT(*) as count
		FROM invoices
		WHERE status = 'paid'
		  AND paid_at >= NOW() - INTERVAL '%d days'
		  AND deleted_at IS NULL
		GROUP BY TO_CHAR(paid_at, 'YYYY-MM-DD')
		ORDER BY date ASC
	`, days)
	err := r.db.Raw(query).Scan(&result).Error
	return result, err
}
