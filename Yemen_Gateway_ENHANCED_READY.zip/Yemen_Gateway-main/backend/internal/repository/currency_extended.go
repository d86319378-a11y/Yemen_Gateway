package repository

// currency_extended.go — دوال إضافية لـ CurrencyRepository
// أضف هذا الملف إلى جانب currency.go الموجود. لا تعدّل currency.go.

import (
	"time"
	"yemenapi/internal/domain"

	"github.com/google/uuid"
)

// CreateRate — ينشئ سعر صرف جديد (يُستخدم من Admin handler)
func (r *CurrencyRepository) CreateRate(rate *domain.CurrencyRate) error {
	return r.db.Create(rate).Error
}

// UpdateRateByID — يحدّث سعر الصرف بالمعرّف (UUID)
func (r *CurrencyRepository) UpdateRateByID(id uuid.UUID, newRate float64, source string) (*domain.CurrencyRate, error) {
	var rate domain.CurrencyRate
	if err := r.db.First(&rate, "id = ?", id).Error; err != nil {
		return nil, err
	}
	rate.Rate = newRate
	rate.Source = source
	rate.Date = time.Now()
	if err := r.db.Save(&rate).Error; err != nil {
		return nil, err
	}
	return &rate, nil
}

// GetRateHistory — يُعيد تاريخ الأسعار لزوج عملات معيّن
func (r *CurrencyRepository) GetRateHistory(fromCode, toCode string, limit int) ([]domain.CurrencyRate, error) {
	if limit <= 0 {
		limit = 30
	}
	var rates []domain.CurrencyRate
	err := r.db.
		Where("from_code = ? AND to_code = ?", fromCode, toCode).
		Order("created_at DESC").
		Limit(limit).
		Find(&rates).Error
	return rates, err
}

// GetAllRatesWithHistory — يُعيد آخر سعر لكل عملة مع وقت التحديث
func (r *CurrencyRepository) GetAllRatesWithMeta() ([]domain.CurrencyRate, error) {
	var rates []domain.CurrencyRate
	// آخر سعر لكل زوج
	err := r.db.Raw(`
		SELECT DISTINCT ON (from_code, to_code) *
		FROM currency_rates
		WHERE to_code = 'YER'
		ORDER BY from_code, to_code, created_at DESC
	`).Scan(&rates).Error
	if err != nil {
		// fallback if DISTINCT ON not supported
		return r.GetAllRates()
	}
	return rates, nil
}
